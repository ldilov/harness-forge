---
id: semiformal-agentic-kit
kind: bundle-readme
title: Semi-formal Agentic Reasoning Kit
summary: Markdown contracts, certificates, evidence ledgers, and workflows for evidence-backed repository reasoning and change review.
status: stable
version: 1
source_paper: "Agentic Code Reasoning (Meta, arXiv:2603.01896)"
---

# Semi-formal Agentic Reasoning Kit

This kit turns the paper's core idea into reusable Markdown operating surfaces for real engineering work:

- **reasoning must produce a certificate, not a vibe**
- **every claim must point to explicit premises and evidence**
- **the agent must trace code paths instead of guessing from names**
- **equivalence claims need either a counterexample or an explicit no-counterexample argument**
- **exploration itself should be structured, not just the final answer**

The source paper studied this pattern on three tasks:

1. **patch equivalence**
2. **fault localization**
3. **code question answering**

The paper's main insight is that *semi-formal reasoning* sits between informal chain-of-thought and full formal proof. It keeps natural language, but forces explicit structure: premises, traces, claims, evidence, alternative hypotheses, and a formal conclusion.

This bundle keeps that spine intact and generalizes it into a project-ready set of templates so teams can standardize agent behavior across engineering tasks.

## What is inside

### Core operating surfaces

- `templates/contracts/semiformal-core-contract.md`
- `templates/logs/semiformal-exploration-log.md`
- `templates/ledgers/function-trace-table.md`
- `templates/ledgers/data-flow-and-semantic-properties.md`

### Task certificates aligned to the paper

- `templates/certificates/patch-equivalence-certificate.md`
- `templates/certificates/fault-localization-certificate.md`
- `templates/certificates/code-question-answering-certificate.md`

### Project generalization for day-to-day engineering

- `templates/certificates/change-safety-certificate.md`

### Workflows

- `workflows/universal-semiformal-investigation-workflow.md`
- `workflows/pre-merge-semiformal-review-workflow.md`

### Strategy and adoption

- `docs/paper-source-map.md`
- `docs/adoption-strategy.md`
- `docs/template-selection-guide.md`
- `integration/harness-forge-placement.md`

### Mini case studies

- `examples/django-name-shadowing-mini-case-study.md`
- `examples/mockito-root-cause-mini-case-study.md`

## Design principles preserved from the paper

This kit intentionally preserves the paper's strongest constraints:

1. **Premises first**
   - the agent must state what it believes the task, tests, or semantics require before concluding anything.

2. **Execution-path tracing**
   - the agent must follow actual definitions and calls through the repository, especially when names can mislead.

3. **Evidence-bearing claims**
   - every claim must cite file locations, observations, traced behavior, or explicit negative evidence.

4. **Alternative-hypothesis pressure**
   - the agent must check what would need to be true for the opposite answer to hold.

5. **Formal conclusion**
   - the final answer must be derivable from the prior sections, not invented at the end.

6. **Exploration discipline**
   - when the agent reads more files, it must explain why that file matters, what hypothesis it is testing, and how the new evidence updates that hypothesis.

## Recommended rollout order

### Level 1 - universal team baseline

Use these on every meaningful investigation, review, or risky change:

- `templates/contracts/semiformal-core-contract.md`
- `templates/logs/semiformal-exploration-log.md`
- `templates/certificates/change-safety-certificate.md`

### Level 2 - task-specific rigor

Use the paper-aligned certificates when the task matches:

- patch comparison or solution verification -> patch equivalence certificate
- bug hunt or failure triage -> fault localization certificate
- repo question answering or code review explanation -> code QA certificate

### Level 3 - pre-merge enforcement

Before merge on risky changes, require:

- exploration log
- relevant certificate
- counterexample or no-counterexample section
- explicit unresolved assumptions
- formal ship / no-ship conclusion

## Non-negotiable team rules

- no unsupported conclusion section
- no "looks equivalent" wording without trace evidence
- no guessing based only on names or surface diff similarity
- no final answer that cannot be reconstructed from premises + claims + evidence
- no skipping the alternative hypothesis when the answer is high impact
- no silent uncertainty; unresolved assumptions must be surfaced explicitly

## The most important operational lesson

The paper shows the value is **not** just prettier formatting. The value comes from changing the agent's behavior: structured templates force it to gather evidence before concluding. This kit is built to preserve that behavioral pressure.

See `docs/paper-source-map.md` for a precise mapping from this bundle back to the paper.
