# Harness Forge Enhancement Requirements

## Purpose

This document defines a concrete enhancement plan for four next-step capabilities in Harness Forge:

1. Harness capability matrix
2. Repo cartographer / instruction synthesizer
3. Observability and eval knowledge
4. Parallel worktree supervisor

It is written to be implementation-ready for the current package layout and release model.

---

## Why these four first

Harness Forge already ships the foundations needed to support these upgrades:

- target adapters exist for `codex`, `claude-code`, `cursor`, and `opencode`
- repo intelligence exists via `scripts/intelligence/*`
- flow orchestration exists via `.specify/state/*` and `docs/flow-orchestration.md`
- local observability already exists via `.hforge/observability/effectiveness-signals.json`
- hooks and compatibility manifests already exist under `manifests/hooks/` and `manifests/catalog/`

The gap is not basic infrastructure. The gap is deeper modeling, stronger runtime honesty, and more explicit data contracts.

---

## Current state summary

### Already shipped

- `docs/target-support-matrix.md` gives a high-level support table
- `manifests/catalog/compatibility-matrix.json` already contains compatibility entries
- `scripts/intelligence/shared.mjs` detects dominant languages, build/test/deploy signals, risks, missing validation surfaces, and framework hints
- `docs/observability.md` defines local-first observability goals
- `docs/flow-orchestration.md` defines stage and lineage concepts
- `manifests/hooks/index.json` already models typed hook metadata
- target adapters already expose support flags such as `supportsHooks`, `supportsAgents`, `supportsCommands`, `supportsContexts`, and `capabilityMatrix`

### Current limitations

- the matrix is descriptive, not yet an operational source of truth for install, recommend, validate, and docs generation
- repo intelligence detects signals, but does not synthesize scoped instruction surfaces such as nested `AGENTS.md`, Cursor rules, or target-aware mapping packs
- observability tracks usage signals, but not evaluation quality, recommendation precision, false positives, workflow completion rates, or benchmark regressions
- there is no first-class worktree planning model for parallel task sharding, branch policy, result collection, or merge safety
- partial-support targets are honest, but not deeply modeled by capability family, adapter strategy, fallback quality, and test coverage level

---

# 1. Harness Capability Matrix

## Goal

Turn support claims into a machine-verified capability system that drives:

- installation decisions
- recommendation scoring
- generated docs
- runtime validation
- benchmark expectations
- release gating

## Problem to solve

Right now support is split across:

- `docs/target-support-matrix.md`
- `targets/*/adapter.json`
- `manifests/catalog/compatibility-matrix.json`

Those surfaces overlap, but they are not yet normalized enough to answer questions like:

- Which target supports nested instructions natively vs by translation?
- Which target supports hooks, with what trigger model?
- Which target supports reusable subagents vs only plain docs?
- Which target supports multiple instruction scopes and precedence?
- Which target supports cloud-parallel tasks vs only local worktrees?
- Which capability is native, emulated, documentation-only, or unsupported?

## Required outcome

Create a **capability graph** with enough structure to generate all public support tables and to validate target claims automatically.

## Functional requirements

### FR-1 Capability taxonomy
Add a normalized taxonomy for at least these capability families:

- instruction-loading
- instruction-scoping
- nested-instruction-precedence
- command-surface
- reusable-agents
- reusable-skills
- hooks
- hook-event-model
- repo-intelligence
- flow-orchestration
- worktree-or-branch-isolation
- cloud-task-parallelism
- observability
- local-state-recovery
- mcp-support
- install-surface
- profile-support
- recommendation-engine-support
- maintenance-commands
- benchmark-support
- validation-surface

### FR-2 Support modes
Each capability must support an explicit mode enum:

- `native`
- `translated`
- `emulated`
- `documentation-only`
- `partial`
- `unsupported`

### FR-3 Evidence and confidence
Every target-capability entry must carry:

- `supportLevel`
- `supportMode`
- `evidenceSource`
- `lastValidatedAt`
- `validationMethod`
- `confidence`
- optional `notes`
- optional `fallbackBehavior`

### FR-4 Target-specific sub-capabilities
The matrix must model target nuances such as:

- instruction file names and discovery rules
- hook file locations and trigger support
- local vs cloud execution model
- subagents availability
- scoped rule availability
- path-based instruction override support
- whether observability is native or package-provided

### FR-5 Doc generation
`docs/target-support-matrix.md` must be generated or partially generated from the matrix source of truth.

### FR-6 Runtime validation
Add CI validation that checks:

- every adapter capability has a matrix entry
- every documented support claim maps to a manifest entry
- unsupported capabilities are not accidentally advertised in README/profile/install docs
- partial support claims include explicit notes and fallback behavior

### FR-7 Recommendation integration
Recommendation scoring must be able to ask questions like:

- prefer native hook surfaces when installing workflow-quality bundle
- avoid target-only profiles on unsupported targets
- downgrade confidence when a feature depends on emulation

## Non-functional requirements

- matrix must be human-readable and machine-validated
- matrix must stay compact enough to review in PRs
- docs derived from the matrix must preserve support honesty
- release validation must fail on undocumented target drift

## Proposed files to add

```text
manifests/catalog/capability-taxonomy.json
manifests/catalog/harness-capability-matrix.json
schemas/manifests/harness-capability-matrix.schema.json
scripts/ci/generate-target-support-docs.mjs
scripts/ci/validate-capability-matrix.mjs
docs/targets/capability-families.md
docs/targets/translation-vs-emulation.md
```

## Existing files to update

```text
docs/target-support-matrix.md
manifests/catalog/compatibility-matrix.json
targets/claude-code/adapter.json
targets/codex/adapter.json
targets/cursor/adapter.json
targets/opencode/adapter.json
README.md
docs/install/targets.md
```

## Acceptance criteria

- one matrix source produces the target support doc and validation checks
- support claims are no longer hard-coded in multiple inconsistent places
- recommendation logic can use matrix values directly
- adding a new target requires matrix entries before docs pass CI

## Data to include

For each target, include at minimum:

- instruction file(s)
- scope model
- precedence model
- hook support details
- subagent support
- worktree or branch isolation support
- cloud execution support
- docs fallback strategy
- install surface mapping
- validation coverage status
- benchmark coverage status

---

# 2. Repo Cartographer / Instruction Synthesizer

## Goal

Evolve repo intelligence from passive detection into **repo-aware instruction generation**.

The system should scan a repository, identify its execution model and risk areas, then synthesize the right instruction surfaces for the target harness.

## Problem to solve

Current repo intelligence can detect build/test/framework signals, but it does not yet produce:

- scoped `AGENTS.md` maps
- nested per-folder instructions
- Cursor rules drafts
- target-aware instruction packs
- recommended docs to generate under `docs/`
- quality gate suggestions based on repo topology

## Required outcome

Create a cartography pipeline that converts repo facts into a structured map and then emits target-aware instruction assets.

## Functional requirements

### FR-1 Canonical repo map
Create a repo map model with these sections:

- repo identity
- dominant languages
- frameworks
- package managers
- build graph hints
- test topology
- deploy topology
- service boundaries
- app/library/tooling boundaries
- critical folders
- high-risk folders
- likely generated folders
- likely secrets/config folders
- docs surfaces
- existing instruction surfaces
- probable owners or domains inferred from paths

### FR-2 Folder classification
Support directory classification such as:

- app
- api
- ui
- infra
- db
- worker
- packages
- sdk
- engine
- tools
- scripts
- tests
- docs
- generated
- migrations
- security-sensitive

### FR-3 Instruction synthesis
Generate drafts for:

- root `AGENTS.md`
- nested `AGENTS.md` files for scoped subtrees
- Cursor `.cursor/rules/*.mdc` rules
- optional `.hforge/generated/repo-map.json`
- optional `.hforge/generated/instruction-plan.json`
- docs stubs such as `docs/generated/repo-map.md`

### FR-4 Instruction placement strategy
The synthesizer must decide:

- when root-only instructions are enough
- when nested instructions are justified
- which rules belong to global vs scoped surfaces
- which instructions should point to deeper docs instead of embedding detail

### FR-5 Quality and safety heuristics
Instruction synthesis must consider:

- repo size
- monorepo vs single package
- mixed-language boundaries
- generated code areas
- security-sensitive areas
- migration-heavy areas
- testless hotspots
- build fragility markers

### FR-6 Target-aware emission
For each target, emit the closest native surface:

- Codex: `AGENTS.md` strategy, nested scope recommendations, worktree and validation guidance
- Claude Code: `CLAUDE.md`, `.claude/agents/`, hook-compatible guidance, path-aware docs guidance
- Cursor: project rules, `AGENTS.md` fallback, rule scope recommendations
- OpenCode: adapter guidance, docs-only fallback until deeper runtime exists

### FR-7 Explainability
Every generated instruction section must include provenance metadata such as:

- why it was generated
- which evidence triggered it
- confidence score
- which files/paths supported the conclusion

### FR-8 Dry run and diff mode
Add CLI support for:

- `scan`
- `cartograph`
- `synthesize-instructions`
- `--json`
- `--dry-run`
- `--write`
- `--diff`

## Non-functional requirements

- generated instructions must stay concise and navigational
- nested instructions must only be added when value outweighs maintenance cost
- instruction generation must be deterministic for the same repo state
- generated artifacts must be safe to check into source control

## Proposed files to add

```text
scripts/intelligence/cartograph-repo.mjs
scripts/intelligence/synthesize-instructions.mjs
scripts/intelligence/classify-boundaries.mjs
scripts/intelligence/shared/cartography.mjs
schemas/runtime/repo-map.schema.json
schemas/runtime/instruction-plan.schema.json
templates/instructions/root-agents-template.md
templates/instructions/scoped-agents-template.md
templates/instructions/cursor-rule-template.mdc
docs/repo-cartography.md
skills/repo-cartographer/SKILL.md
```

## Existing files to update

```text
scripts/intelligence/shared.mjs
scripts/intelligence/scan-repo.mjs
scripts/intelligence/score-recommendations.mjs
docs/targets.md
docs/quickstart.md
README.md
```

## Acceptance criteria

- given a repo, the system can output a stable repo map JSON
- instruction synthesis can emit root and nested instruction drafts
- generated output contains evidence for each major recommendation
- recommendation scoring improves by using repo map boundaries, not only file markers

## Data to include

The repo map should store:

- `workspaceType`
- `dominantLanguages[]`
- `frameworks[]`
- `packages[]`
- `services[]`
- `criticalPaths[]`
- `highRiskPaths[]`
- `instructionScopes[]`
- `qualityGaps[]`
- `recommendedProfiles[]`
- `recommendedSkills[]`
- `recommendedHooks[]`
- `recommendedTargets[]`
- `supportingEvidence[]`

---

# 3. Observability and Eval Knowledge

## Goal

Upgrade local observability from “was something run?” into “was it good, useful, and improving over time?”

This should cover both:

- operational observability
- evaluation knowledge and benchmark interpretation

## Problem to solve

Current signal logging captures events such as `flow-status`, `doctor-run`, `audit-run`, and `diff-install-run`, but it does not yet measure:

- recommendation precision and acceptance quality
- benchmark pass/fail by scenario and target
- skill usefulness by task type
- false positive and false negative rates for repo intelligence
- time-to-resume from interrupted flow state
- worktree parallelization efficiency
- docs drift or capability drift over time

## Required outcome

Create an observability model with **events**, **summaries**, **benchmarks**, and **evaluation guidance** that stays local-first.

## Functional requirements

### FR-1 Event taxonomy
Define event families for at least:

- install
- recommend
- scan
- synthesize-instructions
- hook-run
- maintenance-run
- flow-transition
- flow-recovery
- benchmark-run
- benchmark-assertion
- release-validation
- worktree-plan
- worktree-task
- worktree-merge
- skill-invocation
- target-adapter-translation

### FR-2 Event schema
Each event must support:

- `eventId`
- `eventType`
- `recordedAt`
- `workspaceId`
- `target`
- `featureId` when relevant
- `result`
- `durationMs`
- `confidence`
- `inputs`
- `outputs`
- `artifacts`
- `evidence`
- `tags`

### FR-3 Derived summaries
Add local summary generation for:

- recommendation acceptance rate
- benchmark pass rate by target
- median flow recovery success time
- hook failure rate by family
- most useful skills by accepted outcome
- missing-validation hotspots across benchmark fixtures
- target drift and unsupported-claim warnings

### FR-4 Eval knowledge base
Add documentation and examples for:

- what to benchmark
- how to measure recommendation quality
- how to score capability drift
- how to score synthesized instruction quality
- how to measure partial-target degradation honestly
- how to create regression fixtures

### FR-5 Benchmark scenario metadata
Extend benchmark fixtures to carry richer expectations:

- expected repo map
- expected recommendations
- expected target support warnings
- expected instruction scopes
- expected quality gaps
- expected observability events

### FR-6 Local report surfaces
Generate:

- machine-readable summary JSON
- markdown report for handoff/release review
- per-target benchmark summaries
- per-feature flow effectiveness summaries

### FR-7 Privacy boundary
The system must remain local-first:

- no external collector required
- signal files human-inspectable
- removable without breaking install surfaces
- redaction support for sensitive paths if desired later

## Knowledge-base requirements

Add reference material on:

- event design principles
- benchmark scenario design
- recommendation quality scoring
- target-support honesty rules
- how to interpret precision vs recall for repo intelligence
- how to interpret operational vs evaluative signals

## Non-functional requirements

- event files must stay append-safe and diff-friendly
- summaries must be reproducible from raw events
- event schemas must support future target expansion
- metrics must be understandable without external dashboards

## Proposed files to add

```text
schemas/runtime/observability-event.schema.json
schemas/runtime/observability-summary.schema.json
schemas/runtime/benchmark-expectation.schema.json
scripts/runtime/record-event.mjs
scripts/runtime/summarize-observability.mjs
scripts/runtime/render-observability-report.mjs
docs/observability/event-taxonomy.md
docs/observability/eval-model.md
docs/observability/benchmark-authoring.md
knowledge-bases/operations/observability-and-evals/README.md
knowledge-bases/operations/observability-and-evals/event-design.md
knowledge-bases/operations/observability-and-evals/recommendation-quality.md
knowledge-bases/operations/observability-and-evals/benchmark-patterns.md
skills/observability-and-eval/SKILL.md
```

## Existing files to update

```text
docs/observability.md
docs/benchmark-scenarios.md
.hforge/observability/effectiveness-signals.json
scripts/runtime/report-effectiveness.mjs
manifests/catalog/flow-artifacts.json
README.md
```

## Acceptance criteria

- raw events can produce stable summary reports
- benchmarks can assert expected repo-intelligence output and target warnings
- recommendation quality can be measured across fixtures
- observability docs explain how to read the numbers and act on them

## Data to include

Minimum summary metrics:

- installs by target/profile/lang
- recommendations shown vs accepted vs rejected
- false-positive recommendations
- missing required recommendations
- flow recovery success rate
- median stage resume time
- hook success and failure counts
- benchmark pass rate by fixture
- capability drift findings
- instruction synthesis acceptance rate
- worktree shard completion rate

---

# 4. Parallel Worktree Supervisor

## Goal

Provide a first-class orchestration layer for parallel implementation using isolated worktrees or equivalent execution shards.

This should help the harness decide:

- whether parallelism is worth it
- how to split work safely
- how to assign tasks to shards
- how to merge results without chaos

## Problem to solve

Harness Forge already talks about orchestration and flow recovery, but it does not yet own:

- a task sharding model
- a worktree plan format
- merge readiness checks
- cross-shard dependency handling
- benchmark coverage for parallel task execution

## Required outcome

Create a worktree supervisor that plans, tracks, and evaluates parallel work.

## Functional requirements

### FR-1 Worktree planning model
Add a plan model containing:

- root task
- shardable tasks
- dependency graph
- shared-risk files
- merge strategy
- validation plan
- rollback plan
- completion criteria

### FR-2 Sharding heuristics
The supervisor must score whether work is safe to split based on:

- file overlap risk
- dependency ordering
- migration risk
- shared config risk
- test coupling
- expected merge complexity
- target runtime support quality

### FR-3 Execution modes
Support at least:

- single-thread recommendation only
- local worktree parallel plan
- cloud-task parallel plan
- emulated parallel plan for partial targets

### FR-4 State tracking
Persist state for:

- worktree id
- shard id
- assigned task ids
- active status
- branch or worktree path
- last check-in
- validation status
- merge readiness
- blockers

### FR-5 Merge safety
Before merge or squash recommendations, validate:

- overlapping file edits
- conflicting instruction scopes
- failing validation in any shard
- stale base branch
- missing docs/tests from required shard outputs

### FR-6 Flow integration
Worktree state must integrate with `.specify/state/flow-state.json` and artifact lineage.

### FR-7 Observability integration
Each supervisor action must emit events for:

- plan creation
- shard start
- shard completion
- merge blocked
- merge success
- rollback
- abandoned shard

### FR-8 Operator surfaces
Add CLI commands such as:

- `flow parallel-plan`
- `flow parallel-status`
- `flow shard-complete`
- `flow merge-check`
- `flow merge-report`

## Non-functional requirements

- state must be resumable after interruption
- plans must be inspectable by humans
- supervisor must fail safe when overlap risk is high
- partial-target support must be clearly degraded, not implied as native

## Proposed files to add

```text
schemas/runtime/worktree-plan.schema.json
schemas/runtime/worktree-state.schema.json
scripts/runtime/create-parallel-plan.mjs
scripts/runtime/check-parallel-status.mjs
scripts/runtime/check-merge-readiness.mjs
docs/parallel-worktrees.md
docs/flow-orchestration/parallel-execution.md
skills/parallel-worktree-supervisor/SKILL.md
templates/workflows/parallel-implement-and-merge.md
```

## Existing files to update

```text
docs/flow-orchestration.md
manifests/catalog/flow-artifacts.json
manifests/hooks/index.json
scripts/runtime/flow-status.mjs
README.md
```

## Acceptance criteria

- a feature backlog can be converted into a parallel plan with shard metadata
- unsafe overlap produces a blocked or single-thread recommendation
- merge readiness check explains exactly why a merge is blocked
- parallel state survives interruption and can be resumed

## Data to include

Minimum plan fields:

- `planId`
- `featureId`
- `strategy`
- `shards[]`
- `dependencies[]`
- `sharedRiskPaths[]`
- `expectedArtifacts[]`
- `validationGates[]`
- `mergeCriteria[]`
- `fallbackToSingleThreadReason`

---

# Cross-cutting implementation plan

## Phase 1 — Normalize contracts

Deliver first:

- capability taxonomy
- matrix schema
- repo map schema
- observability event schema
- worktree plan/state schemas

## Phase 2 — Add generators and validators

Deliver next:

- matrix generator and validator
- repo cartography generator
- instruction synthesizer
- observability summarizer
- parallel plan generator and merge checker

## Phase 3 — Wire into CLI and docs

Deliver next:

- CLI commands
- generated markdown reports
- README and target docs updates
- benchmark expectation expansion

## Phase 4 — Benchmark and harden

Deliver next:

- benchmark fixtures for monorepo, app, library, mixed-language, infra-heavy, migration-heavy repos
- target-specific capability drift checks
- recommendation quality baselines
- instruction synthesis golden outputs
- parallel worktree decision regression tests

---

# Suggested benchmark fixtures to add

```text
tests/fixtures/benchmarks/ts-monorepo-web-api
tests/fixtures/benchmarks/dotnet-service-with-migrations
tests/fixtures/benchmarks/python-fastapi-worker
tests/fixtures/benchmarks/cpp-unreal-plugin
tests/fixtures/benchmarks/mixed-repo-frontend-backend-infra
tests/fixtures/benchmarks/repo-with-generated-code
tests/fixtures/benchmarks/repo-without-tests
```

For each fixture, include:

- expected repo map
- expected recommendations
- expected support warnings by target
- expected instruction surfaces to synthesize
- expected observability summary deltas
- expected parallelization decision

---

# Proposed release gates

Add release checks that fail when:

- matrix doc and matrix manifest drift
- adapter capability claims lack evidence
- synthesized instruction output changes without updated golden outputs
- observability event schema changes without summary compatibility
- worktree plan logic enables unsafe parallelism for overlap-heavy fixtures

---

# Risks and trade-offs

## Risk 1: Over-modeling
Too much schema detail can slow iteration.

**Mitigation:** keep v1 focused on data that drives real automation.

## Risk 2: Instruction bloat
Repo cartography can generate too many scoped docs.

**Mitigation:** require confidence and maintenance-value thresholds before adding nested instruction files.

## Risk 3: Misleading parity claims
Partial targets may look more complete than they are.

**Mitigation:** matrix must distinguish native, translated, emulated, and documentation-only support.

## Risk 4: Noisy local telemetry
Raw events can become hard to inspect.

**Mitigation:** keep append-only raw events and derived summaries separate.

## Risk 5: Parallel merge chaos
Worktree parallelism can damage trust if merge checks are weak.

**Mitigation:** block aggressively when shared-risk paths or dependency overlap are high.

---

# Recommended build order

1. Harness capability matrix
2. Repo cartographer / instruction synthesizer
3. Observability and eval knowledge
4. Parallel worktree supervisor

This order gives the later features better foundations:

- the matrix defines target truth
- cartography uses that truth to emit target-aware instructions
- observability measures whether the recommendations are good
- the worktree supervisor uses repo map, target truth, and observability signals together

---

# Minimal v1 deliverables

If you want a lean first milestone, ship this set first:

## v1 deliverables

- `harness-capability-matrix.json`
- capability matrix schema + validator
- `repo-map.json` output + schema
- instruction synthesis dry-run only
- observability event schema + summary generator
- worktree plan schema + dry-run planner
- docs for all four areas
- 4 to 6 benchmark fixtures with golden expectations

## v1 explicitly out of scope

- full automatic file writing into user repos by default
- remote telemetry backends
- auto-merge without validation gates
- deep OpenCode runtime parity claims
- advanced redaction pipeline

---

# Suggested source notes for implementation

Use official source material to keep support claims fresh:

- OpenAI Codex docs and product posts for AGENTS.md scope, approval modes, cloud tasks, and Codex app/cloud surfaces
- Anthropic Claude Code docs for settings, hooks, subagents, and project/user scope
- Cursor docs for project rules, AGENTS.md support, and scoped rules behavior
- OpenTelemetry semantic conventions docs for observability terminology and naming discipline

---

# Ready-to-build checklist

## Capability matrix
- [ ] schema defined
- [ ] taxonomy defined
- [ ] target entries added
- [ ] doc generator added
- [ ] validator added

## Repo cartographer
- [ ] repo-map schema defined
- [ ] folder classification added
- [ ] instruction-plan schema defined
- [ ] synthesis templates added
- [ ] CLI commands added

## Observability and eval
- [ ] event schema defined
- [ ] summary schema defined
- [ ] summary generator added
- [ ] benchmark expectation schema expanded
- [ ] knowledge docs added

## Parallel worktree supervisor
- [ ] worktree plan schema defined
- [ ] worktree state schema defined
- [ ] planner added
- [ ] merge readiness checker added
- [ ] docs and templates added

