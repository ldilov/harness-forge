---
name: parallel-worktree-supervisor
description: auto-discoverable wrapper for splitting work safely across git worktrees or stacked branches.
---

# Parallel Worktree Supervisor

## Activation

- trigger when a backlog could be split into low-overlap tracks or when stacked review sequencing is needed

## Use These Surfaces

- `skills/parallel-worktree-supervisor/SKILL.md`
- `skills/parallel-worktree-supervisor/references/`
- task lists, branch plans, and validation surfaces in the repository

## Expected Output

- a branch or worktree plan with overlap hotspots, blockers, and merge order grounded in the canonical skill
