---
name: api-contract-review
description: auto-discoverable wrapper for http, event, schema, and generated-client contract review.
---

# API Contract Review

## Activation

- trigger when route definitions, specs, schemas, SDKs, or integration contracts change

## Use These Surfaces

- `skills/api-contract-review/SKILL.md`
- `skills/api-contract-review/references/`
- source-of-truth specs, validators, and client-facing docs in the repository

## Expected Output

- a compatibility-focused contract review with consumer impact and follow-up actions grounded in the canonical skill
