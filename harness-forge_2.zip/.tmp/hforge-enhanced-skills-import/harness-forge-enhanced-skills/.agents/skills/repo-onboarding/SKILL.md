---
name: repo-onboarding
description: auto-discoverable wrapper for fast discovery of unfamiliar repositories, commands, boundaries, and ownership signals.
---

# Repository Onboarding

## Activation

- trigger when the next safe step is blocked on understanding repository layout, commands, or ownership

## Use These Surfaces

- `skills/repo-onboarding/SKILL.md`
- `skills/repo-onboarding/references/`
- top-level manifests, docs, and repo-native guidance surfaces

## Expected Output

- a concise onboarding brief with commands, hotspots, and recommended next surfaces to inspect grounded in the canonical skill
