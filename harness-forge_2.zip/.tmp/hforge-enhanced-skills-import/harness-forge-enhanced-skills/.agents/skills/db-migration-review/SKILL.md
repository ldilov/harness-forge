---
name: db-migration-review
description: auto-discoverable wrapper for migration safety review, backfill planning, and rollout or rollback analysis.
---

# DB Migration Review

## Activation

- trigger when migration files, DDL, ORM schema diffs, backfills, or deployment-order questions change

## Use These Surfaces

- `skills/db-migration-review/SKILL.md`
- `skills/db-migration-review/references/`
- migration, schema, and deployment surfaces in the repository

## Expected Output

- a risk-ranked migration review with compatibility, rollout, and reversibility guidance grounded in the canonical skill
