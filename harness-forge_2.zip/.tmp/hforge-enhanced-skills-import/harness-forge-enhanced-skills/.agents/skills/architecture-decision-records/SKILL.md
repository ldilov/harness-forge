---
name: architecture-decision-records
description: auto-discoverable wrapper for durable adrs that capture architecture, runtime, package, and workflow decisions.
---

# Architecture Decision Records

## Activation

- trigger when a decision should stay reviewable beyond the current implementation session

## Use These Surfaces

- `skills/architecture-decision-records/SKILL.md`
- `skills/architecture-decision-records/references/`
- specs, plans, and design notes related to the decision

## Expected Output

- a concise ADR or ADR update with decision drivers, alternatives, and consequences grounded in the canonical skill
