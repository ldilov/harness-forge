---
name: javascript-engineering
description: auto-discoverable javascript wrapper for node.js, browser, cli, bundler, and package-contract tasks.
origin: Harness Forge
---

# JavaScript Engineering

## Activation

- trigger when JavaScript runtime behavior, package contracts, module format, or bundler behavior dominate the task more than TypeScript typing concerns

## Use These Surfaces

- `skills/javascript-engineering/SKILL.md`
- `skills/javascript-engineering/references/`
- `rules/common/`

## Expected Output

- a JavaScript-specific implementation, review, or debugging path grounded in the canonical skill and repo evidence
