---
name: repo-modernization
description: auto-discoverable wrapper for phased modernization planning across tooling, dependencies, and architecture seams.
---

# Repo Modernization

## Activation

- trigger when the repo shows legacy drag, dependency drift, brittle workflows, or rewrite pressure that needs a phased plan

## Use These Surfaces

- `skills/repo-modernization/SKILL.md`
- `skills/repo-modernization/references/`
- build, dependency, and architecture surfaces in the repository

## Expected Output

- a staged modernization roadmap with safety rails, automation candidates, and migration sequencing grounded in the canonical skill
