---
name: dotnet-engineering
description: auto-discoverable .net wrapper for c#, asp.net core, ef core, worker service, test, and package-boundary tasks.
origin: Harness Forge
---

# .NET Engineering

## Activation

- trigger when `.cs`, `.csproj`, `.sln`, ASP.NET Core, EF Core, workers, or .NET package surfaces dominate the task

## Use These Surfaces

- `skills/dotnet-engineering/SKILL.md`
- `skills/dotnet-engineering/references/`
- `rules/common/`
- `rules/dotnet/`
- `knowledge-bases/seeded/dotnet/`
- `templates/workflows/implement-dotnet-change.md`

## Expected Output

- a .NET-specific implementation, review, or debugging path grounded in the canonical skill and repo evidence
