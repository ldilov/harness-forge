---
name: typescript-engineering
description: auto-discoverable typescript wrapper for node, react, next.js, workspace, and contract-boundary tasks.
origin: Harness Forge
---

# TypeScript Engineering

## Activation

- trigger when `.ts`, `.tsx`, `package.json`, `tsconfig`, workspace config, or TypeScript-first runtime contracts dominate the task

## Use These Surfaces

- `skills/typescript-engineering/SKILL.md`
- `skills/typescript-engineering/references/`
- `rules/common/`
- `rules/typescript/`
- `knowledge-bases/seeded/typescript/`
- `templates/workflows/implement-typescript-change.md`

## Expected Output

- a TypeScript-specific implementation, review, or debugging path grounded in the canonical skill and repo evidence
