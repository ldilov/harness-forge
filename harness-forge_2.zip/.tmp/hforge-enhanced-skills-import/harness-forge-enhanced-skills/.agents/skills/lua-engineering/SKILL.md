---
name: lua-engineering
description: auto-discoverable lua wrapper for neovim, openresty, love2d, embedded lua, and luajit-sensitive tasks.
origin: Harness Forge
---

# Lua Engineering

## Activation

- trigger when `.lua` files, host-specific Lua config, Neovim, OpenResty, Love2D, or runtime-flavor constraints dominate the task

## Use These Surfaces

- `skills/lua-engineering/SKILL.md`
- `skills/lua-engineering/references/`
- `rules/common/`
- `rules/lua/`
- `knowledge-bases/seeded/lua/`
- `templates/workflows/implement-lua-change.md`

## Expected Output

- a Lua-specific implementation, review, or debugging path grounded in the canonical skill and repo evidence
