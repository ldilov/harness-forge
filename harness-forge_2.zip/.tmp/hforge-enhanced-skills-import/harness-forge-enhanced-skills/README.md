# Harness Forge Enhanced Skills Pack

This pack contains upgraded versions of these skills:

- dotnet-engineering
- db-migration-review
- api-contract-review
- architecture-decision-records
- parallel-worktree-supervisor
- repo-modernization
- repo-onboarding
- lua-engineering
- typescript-engineering
- javascript-engineering

## What changed

- Added deeper trigger logic, inspection order, workflow contracts, output contracts, failure modes, and escalation guidance for operational skills.
- Expanded language skills with activation, load order, execution contracts, validation guidance, and richer supplemental reference packs.
- Added new auto-discoverable wrappers under `.agents/skills/` for the skills that were missing them.
- Grounded the guidance in upstream tooling and project patterns from GitHub and official docs, especially around migrations, API governance, ADRs, worktrees, modernization, and modern language tooling.

## Included structure

- `skills/<skill>/` contains the canonical upgraded skill.
- `.agents/skills/<skill>/` contains the lightweight auto-discovery wrapper.
- `RESEARCH-SOURCES.md` summarizes the external resources used to shape the upgrades.
- `VALIDATION.md` summarizes the checks run on the upgraded pack.
