# Harness Forge Runtime & Token-Efficiency Design Pack

This pack turns the brainstorming into a concrete written specification set for Harness Forge.

## What is in this pack

- `01-runtime-native-agentic-architecture.md`  
  Command-optional, runtime-native architecture for autonomous agents and operators.

- `02-retrieval-dedup-and-authority-model.md`  
  A dedup-first retrieval model that keeps capability depth without noisy repeated retrieval.

- `03-output-token-policy-and-response-profiles.md`  
  A concrete model for reducing output-token spend while keeping useful results.

- `04-multi-target-bridge-spec.md`  
  A compatibility architecture for `AGENTS.md`, `CLAUDE.md`, Codex-style surfaces, and future proprietary formats.

- `05-rollout-plan-validation-and-ci-gates.md`  
  Implementation plan, acceptance criteria, validation rules, and rollout strategy.

- `06-example-artifacts-and-schemas.md`  
  Example JSON, TOML, Markdown, and manifest files that show how the design works in practice.

- `Harness-Forge-Runtime-Spec-Master.md`  
  A single combined master document.

## Design thesis

Harness Forge should not become smaller by deleting capability.  
It should become sharper by shrinking the hot path and making deeper capability lazy, discoverable, and canonical.

The governing rule is:

> Everything should be discoverable.  
> Not everything should be preloaded.  
> Only one thing should be canonical.

## Reading order

1. Runtime architecture
2. Retrieval and deduplication
3. Output token policy
4. Target bridges
5. Rollout and CI
6. Example artifacts

## Intended audiences

- package maintainers
- runtime architects
- AI workflow designers
- operator experience owners
- target-adapter implementers
- knowledgebase/export maintainers


---


# Harness Forge Runtime-Native Agentic Architecture

## Purpose

Define a runtime architecture where Harness Forge behaves like a native agentic operating layer rather than a pile of static text assets or a command-only tool. The operator may execute commands, but agents must be able to orient themselves, discover authoritative guidance, and escalate into deeper capability without being forced through a CLI entrypoint.

## Problem statement

Harness Forge is growing into a serious runtime platform. That is good. The risk is not capability growth itself. The risk is that the agent-facing surface becomes wide, repetitive, and ambiguous enough that the following failure modes appear:

1. The agent loads too much text too early.
2. The agent cannot tell what is canonical.
3. The agent retrieves the same idea from several mirrored surfaces.
4. The operator sees too many commands and too much prose before reaching the next useful action.
5. Runtime power is present, but hidden behind execution patterns that autonomous agents do not naturally follow.

The correct response is not capability reduction. The correct response is to make the runtime layered.

## Architecture principle

Harness Forge should distinguish three classes of surfaces:

1. **Discovery surfaces**  
   Tiny files that tell an agent where truth lives, how to navigate, and how to budget context.

2. **Authority surfaces**  
   Canonical files that contain the real execution contract, real policy, real rules, or real runtime state.

3. **Execution surfaces**  
   Commands, generated launchers, and target-native entrypoints used when the agent or operator wants runtime help, automation, or validation.

These classes must not be collapsed into one another.

## Non-goals

This architecture is not trying to:
- eliminate CLI usage
- eliminate rich skills or deep knowledge
- replace target-native integrations with one generic file
- make every target behave identically
- remove generated content from the package entirely

## Core requirement set

### R1. Command-optional orientation

An agent must be able to orient itself without executing a command.

**Requirement:** A fresh agent session in an installed workspace must be able to answer these questions from small runtime files:

- What am I looking at?
- Where is the authoritative AI/runtime layer?
- Which files are discovery wrappers versus canonical bodies?
- Which commands exist if I need them?
- Which runtime artifacts are safe to trust first?
- Which deeper surfaces are available for my task?

**Minimum orientation pack**
- `AGENTS.md`
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`
- `.hforge/runtime/authority-map.json`
- `.hforge/runtime/context-budget.json`

This pack must stay small, stable, and intentionally written.

### R2. Canonical runtime under hidden shared layer

The runtime should preserve the current idea that thin target-facing bridges point into a hidden, shared, canonical layer.

**Requirement:** For installed workspaces, canonical AI content should live under `.hforge/` and target-specific bridges should remain intentionally thin.

This avoids target divergence and keeps one shared truth for:
- skills
- rules
- knowledge
- templates
- runtime findings
- generated catalogs
- observability
- recursive runtime state

### R3. First-hop load budget

The first load should be extremely cheap.

**Requirement:** The total first-hop orientation payload should be constrained by explicit token budgets.

Recommended target:
- `AGENTS.md`: concise bridge file
- manifest + runtime indexes: mostly machine-readable
- combined first-hop load target: under 6k to 12k tokens in realistic deployments

The exact number can vary by profile, but the principle must not.

### R4. Layered hydration

Agents should not preload all depth. They should hydrate depth only when needed.

**Requirement:** Every runtime surface must belong to a load tier:
- **hot**: read first
- **warm**: load when task-relevant
- **cold**: discoverable, but excluded from default retrieval and hot-path loading

### R5. Capability discovery without guesswork

The runtime must answer "what can I do here?" without relying on heuristic scanning alone.

**Requirement:** The runtime must expose machine-readable capability and surface catalogs:
- command catalog
- authority map
- surface tier map
- target capability map
- active recommendations map
- runtime health/findings map

### R6. Human and machine modes should coexist

The operator and the autonomous agent are both first-class users.

**Requirement:** For the same installation:
- operators can inspect and run commands directly
- agents can discover fundamentals passively
- both can converge on the same canonical runtime truth

## Layer model

## Layer A: Bootstrap surfaces

These are the tiny first files that establish context and point to deeper truth.

### Example responsibilities

`AGENTS.md`
- human-readable bridge
- load order hints
- high-level trust/scope rules
- warning not to treat generated/runtime surfaces as product code
- minimal "how to orient" guidance

`.hforge/agent-manifest.json`
- machine-readable contract
- target compatibility
- canonical roots
- generated surfaces
- treat-as-product flags
- discovery bridge references

`.hforge/runtime/index.json`
- index of runtime artifact categories
- paths to runtime findings, recommendations, and current state

`.hforge/runtime/authority-map.json`
- canonical source for each concern
- alias relationships
- retrieval ranking hints

`.hforge/runtime/context-budget.json`
- load order
- token budgets
- suggested exclusions
- brief versus standard versus deep defaults

### Design constraint

These files should reference depth, not reproduce depth.

That means:
- do not duplicate full skill bodies
- do not inline huge rule packs
- do not mirror long templates
- do not include verbose provenance

## Layer B: Resolution surfaces

These files tell the agent how to resolve a task into the right authority surfaces.

Examples:
- `.hforge/generated/agent-command-catalog.json`
- `.hforge/runtime/repo/recommendations.json`
- `.hforge/runtime/repo/repo-map.json`
- `.hforge/runtime/repo/instruction-plan.json`
- `.hforge/runtime/recursive/language-capabilities.json`
- `.hforge/runtime/findings/risk-signals.json`

The agent should be able to answer:
- Which language pack matters?
- Which framework pack matters?
- Which commands are valid?
- Which target-specific capability claims are real?
- Which runtime issues already exist?
- Which paths are safe to ignore?

## Layer C: Deep capability surfaces

These include:
- canonical skills
- canonical rules
- canonical language or framework knowledge
- templates
- runtime traces
- task packs
- recursive run data
- optional provenance and authoring docs

These surfaces are rich and useful, but must not be part of the first-hop load unless the task requires them.

## Runtime contract

The runtime contract should look like this:

1. The agent reads a bridge.
2. The bridge points to the canonical manifest and runtime index.
3. The runtime index points to authority and budget files.
4. The authority map tells the agent what is canonical for the task.
5. The context budget tells the agent what to load next and what to avoid.
6. Optional commands or launchers accelerate work, but are not mandatory.

## Why this is better than command-first design

A command-first design assumes agents naturally ask, "What commands are available?" That is often false. Many agents first read local text, infer structure, and then decide whether to execute anything.

A runtime-native design works with that instinct instead of fighting it.

Advantages:
- less initial friction
- better autonomous discovery
- easier compatibility with multiple target ecosystems
- clearer canonicality model
- lower prompt bloat
- fewer duplicated explanations in chat output

## Required runtime files

### `.hforge/runtime/authority-map.json`

Purpose:
- map conceptual concerns to canonical paths
- mark aliases and generated projections
- drive retrieval deduplication
- help both agents and commands converge on the same truth

Minimum fields:
- `schemaVersion`
- `generatedAt`
- `concepts[]`
  - `conceptId`
  - `title`
  - `canonicalPath`
  - `aliases[]`
  - `surfaceType`
  - `tier`
  - `indexPriority`
  - `reasonToLoad`
  - `reasonToAvoid`

### `.hforge/runtime/context-budget.json`

Purpose:
- encode token budgets and default loading policies

Minimum fields:
- `schemaVersion`
- `profiles`
  - `brief`
  - `standard`
  - `deep`
- `hotSurfaces`
- `warmSurfaces`
- `coldSurfaces`
- `dropOrder`
- `taskProfiles`
- `maxFirstHopTokens`

### `.hforge/runtime/surface-tiers.json`

Optional but recommended.

Purpose:
- explicit hot/warm/cold classification across the installed surface

## Requirements for installation profiles

Harness Forge should support installation or export profiles that control what becomes part of the active runtime.

### Proposed profiles

#### `runtime-minimal`
Smallest viable self-discovery runtime.
Use when:
- minimal prompt cost matters
- a repo already has strong local code context
- the user wants native runtime orientation with lean surface

#### `runtime-standard`
Default recommended install.
Use when:
- broad capability is desired
- retrieval should still be disciplined
- common operators and agents need a balanced experience

#### `maintainer-full`
Full authoring and provenance surface.
Use when:
- editing the package itself
- auditing imports
- reviewing embedded ports and provenance
- working on release internals

#### `kb-lean`
A retrieval-optimized export with canonical bodies and discovery wrappers only.
Use when:
- uploading to a knowledgebase
- indexing in prompt-heavy environments
- sharing runtime guidance with minimal duplication

## Requirements for bridge files

Bridge files must:
- stay short
- tell the truth
- point to canonical runtime paths
- avoid capability overclaiming
- avoid duplicated full-content mirrors
- explain the difference between source-of-truth and generated/runtime surfaces

Bridge files must not:
- contain complete copies of large skills
- act as a second canonical documentation layer
- include hidden historical material
- include temporary import provenance by default

## Example flow: no-command agent orientation

### Scenario
A fresh agent is dropped into an installed workspace.

### Expected behavior
1. Read `AGENTS.md`
2. Learn `.hforge` is canonical
3. Read `.hforge/agent-manifest.json`
4. Read `.hforge/runtime/index.json`
5. Read `.hforge/runtime/authority-map.json`
6. Read `.hforge/runtime/context-budget.json`
7. Decide whether to inspect recommendations, command catalog, or task/runtime findings
8. Optionally execute a command

### Why this works
The agent stays autonomous, but avoids reading a huge surface. The runtime gives just enough structure to make the next read intelligent.

## Example flow: operator-first execution

### Scenario
An operator wants fast help and prefers commands.

### Expected behavior
1. Read bridge or run `hforge commands --json`
2. Inspect `hforge status --root . --json`
3. Use review, update, task, or target inspect commands
4. Refer back to the same `.hforge/runtime/*` truth used by agents

### Why this matters
The runtime architecture should not split operator truth from agent truth. Commands should accelerate access to the same canonical state.

## Anti-patterns

### Anti-pattern A: giant bridge files
A huge `AGENTS.md` that embeds skills, rules, templates, and provenance feels convenient, but destroys first-hop cost and encourages stale duplication.

### Anti-pattern B: every target as its own knowledge system
If `AGENTS.md`, `CLAUDE.md`, `.codex`, and other target surfaces all become separate canonical bodies, the platform eventually becomes inconsistent and expensive.

### Anti-pattern C: generated files pretending to be authored canonical content
Generated runtime projections are useful, but they must be clearly labeled as projections or aliases.

### Anti-pattern D: command-only discoverability
A runtime that only explains itself after running commands is not truly native for autonomous agents.

## Acceptance criteria

This architecture is successful when:

1. A fresh agent can orient itself without commands.
2. The first-hop token cost stays low and measurable.
3. Canonicality is obvious and machine-readable.
4. Deep capability remains available without preload.
5. Operators and agents converge on the same runtime truth.
6. Multi-target bridge files remain thin and honest.
7. Retrieval uses concept-level deduplication rather than file-path fanout.

## Final design statement

Harness Forge should behave like a layered runtime:
- small to enter
- rich to explore
- clear to trust
- optional to execute
- canonical at the center


---


# Retrieval, Deduplication, and Authority Model

## Purpose

Define how Harness Forge can keep broad runtime capability while preventing repeated retrievals, ambiguous truth, and runaway context inflation.

## Problem statement

As Harness Forge grows, the same concept can appear in several places:
- authored source
- discovery wrapper
- generated runtime projection
- packaged distribution copy
- target-specific bridge material
- maintainer documentation
- optional knowledgebase export

Without a disciplined authority model, retrieval systems tend to:
1. return multiple copies of the same idea
2. rank the wrong copy
3. spend tokens on repeated context
4. amplify stale or non-authoritative projections
5. make the agent less confident about what is true

The problem is not duplication in the filesystem alone. The real problem is duplication in the retrieval graph.

## Governing rule

A concept may have many paths.  
A retrieval decision should still produce one authoritative answer.

## Model overview

Harness Forge should use a content-addressed authority model with explicit concept metadata.

Each meaningful unit of guidance should have:

- `conceptId`
- `canonicalPath`
- `contentHash`
- `surfaceRole`
- `retrievalTier`
- `aliasOf` when not canonical
- optional `projectionOf` for generated or transformed forms

This allows the runtime to distinguish:
- true canonical bodies
- short discovery wrappers
- target projections
- generated machine-oriented versions
- cold provenance

## Definitions

### Canonical body
The one path that owns the concept.

Examples:
- canonical skill execution contract
- canonical rule pack
- canonical runtime schema
- canonical adapter spec
- canonical task template

### Alias
A thin pointer or small wrapper that references a canonical body without reproducing it.

Examples:
- `.agents/skills/<skill>/SKILL.md` wrapper
- `AGENTS.md` bridge section
- a summarized target-facing instruction block

### Projection
A generated or transformed representation of a canonical body.

Examples:
- packaged install-time projection
- runtime-generated index
- target-specific emitted config block
- condensed knowledgebase export fragment

### Cold provenance
Useful for maintainers, but not part of default retrieval.

Examples:
- import ledgers
- authoring notes
- temporary unpacked source
- tests and coverage artifacts
- old migration notes
- archived ports

## Requirements

### R1. One canonical body per concept

Every concept must have exactly one canonical body in the active runtime.

**Requirement:** No concept may have multiple canonical bodies in one installation profile.

If two rich files seem equally canonical, that is a design bug.

### R2. Wrappers must be thin

Wrappers are for discovery, not duplication.

**Requirement:** Target wrappers and discovery wrappers should contain:
- purpose
- when to use
- canonical path
- concept ID
- optional very short summary
- optional loading hint

They should not duplicate the full body except where the target absolutely requires it.

### R3. Retrieval must dedupe by concept, not by path

**Requirement:** The retrieval layer should collapse results that share:
- same `conceptId`
- same `contentHash`
- same `aliasOf`
- or high-confidence near-duplicate status

The user should not see four versions of the same skill just because they live in four directories.

### R4. Canonicality must influence ranking

Retrieval ranking should prefer:
1. canonical body
2. canonical generated index if explicitly asked for machine-readable output
3. thin discovery wrapper if the user needs navigation only
4. cold provenance only when specifically requested

### R5. Cold surfaces should not pollute the hot path

Tests, temp imports, archived notes, and provenance should not be indexed as default high-priority retrieval surfaces.

### R6. Generated copies must self-identify

Generated projections must declare:
- whether they are canonical
- what concept they alias or project
- their retrieval priority
- whether they should be hidden in `kb-lean`

## Required metadata

## File-level front matter or adjacent metadata

Each managed AI-facing content file should be trackable with metadata fields similar to:

```yaml
conceptId: skill.typescript-engineering
canonical: true
canonicalPath: .hforge/library/skills/typescript-engineering/SKILL.md
surfaceRole: canonical-body
retrievalTier: warm
indexPriority: high
contentHash: sha256:...
```

For wrappers:

```yaml
conceptId: skill.typescript-engineering
canonical: false
aliasOf: skill.typescript-engineering
surfaceRole: discovery-wrapper
retrievalTier: hot
indexPriority: medium
contentHash: sha256:...
```

For generated projections:

```yaml
conceptId: skill.typescript-engineering
canonical: false
projectionOf: skill.typescript-engineering
surfaceRole: generated-projection
retrievalTier: cold
indexPriority: low
contentHash: sha256:...
```

## Retrieval tier model

### Hot
Readable early and cheaply.
Typical content:
- bridge files
- runtime indexes
- command catalog
- authority map
- context budgets
- active recommendations

### Warm
Load on task demand.
Typical content:
- canonical skills
- canonical rules
- active language packs
- framework packs
- task-specific runtime findings

### Cold
Discoverable, but excluded by default.
Typical content:
- tests
- temp directories
- provenance
- authoring notes
- import ledgers
- coverage outputs
- archived reference material

## Exact duplicate suppression

Exact duplicate suppression is the minimum bar.

**Requirement:** Build-time tooling should detect when the same content body appears verbatim in multiple active retrieval locations.

Recommended actions:
- fail CI if duplication exceeds threshold
- auto-suggest wrapper reduction
- auto-emit duplicate inventory report
- allow explicit whitelists when duplication is required

## Near-duplicate suppression

Exact match is not enough. Near-duplicate prose is often the real token leak.

**Requirement:** Harness Forge should add a near-duplicate detector for AI-facing content.

Candidate approaches:
- normalized-text hashing
- MinHash or simhash over paragraph shingles
- sentence embedding clustering for candidate review
- structured diff similarity for manifests and templates

Use cases:
- long wrappers that paraphrase the canonical body too closely
- target projections that repeat most of a skill
- docs that copy command guidance with small wording changes
- seeded packs that repeat the same common rules block

## Canonicality-aware retrieval ranking

## Suggested ranking formula

```text
retrievalScore =
  taskRelevance
  + canonicalBonus
  + freshnessBonus
  + tierBonus
  - duplicatePenalty
  - projectionPenalty
  - coldSurfacePenalty
```

### Ranking guidance

- canonical body gets highest canonical bonus
- alias wrapper is only preferred for navigation-style queries
- generated projection is only preferred if machine output or target-specific form is requested
- cold provenance is strongly penalized unless explicitly asked for

## Concrete wrapper strategy

### Bad pattern

A wrapper that copies most of the real skill:

```md
# TypeScript Engineering

[500+ lines copied from canonical skill body]
```

This creates:
- duplicated retrieval
- drift risk
- larger target payload
- confusing ranking

### Better pattern

```md
# TypeScript Engineering

Purpose: TypeScript-heavy implementation, architecture, review, typing, refactoring.

Use when:
- the repo is TypeScript-heavy
- the task depends on typing, API contracts, tooling, or build correctness

Canonical contract:
- `.hforge/library/skills/typescript-engineering/SKILL.md`

Concept ID:
- `skill.typescript-engineering`

Load hint:
- read the canonical contract only when the task truly needs it
```

This is still discoverable, but much cheaper.

## Knowledgebase export strategy

A knowledgebase export should not mirror the whole package.

### `kb-lean` principles
- keep canonical bodies
- keep tiny discovery bridges
- remove generated duplicates
- remove cold provenance
- remove coverage, temp, and nested archives
- reduce wrapper size aggressively
- preserve concept metadata

### `kb-lean` should include
- bridge files
- authority map
- context budget
- command catalog
- canonical skills/rules/knowledge/templates
- target adapter specs
- concise docs needed to understand runtime behavior

### `kb-lean` should exclude
- temp folders
- tests and coverage
- build outputs if canonical authored sources exist
- import ledgers unless explicitly requested
- archived packages
- duplicate target projections when adapter mappings are enough

## CI and validation requirements

### Duplicate inventory report
Emit:
- duplicate groups
- canonical representative
- duplicate paths
- total repeated token estimate
- severity

### Wrapper-size validation
Fail or warn when wrappers exceed configured budgets.

Suggested thresholds:
- target bridge wrapper: very small
- discovery skill wrapper: small
- generated projection: depends on target need
- canonical body: not limited by wrapper threshold, but still measurable

### Canonical coverage check
Every active concept should have:
- concept ID
- one canonical path
- zero or more aliases
- optional projections
- defined tier
- ranking metadata

### Cold-surface leakage check
Ensure excluded or cold directories are not accidentally promoted into hot retrieval.

## Example: concept graph

```json
{
  "conceptId": "skill.token-budget-optimizer",
  "canonicalPath": ".hforge/library/skills/token-budget-optimizer/SKILL.md",
  "aliases": [
    ".agents/skills/token-budget-optimizer/SKILL.md"
  ],
  "projections": [
    "dist/cli/.hforge/library/skills/token-budget-optimizer/SKILL.md"
  ],
  "tier": "warm",
  "preferredFor": ["execution", "deep-guidance"],
  "notPreferredFor": ["first-hop-orientation"]
}
```

## Example: retrieval behavior

### Query
"How should I reduce token waste during recursive reviews?"

### Desired outcome
1. return canonical token-budget skill or runtime policy
2. maybe return context-budget runtime file
3. suppress discovery wrapper duplicates
4. suppress generated packaged copy
5. suppress authoring provenance

### Why
The user needs the concept, not the filesystem history.

## Reasoning behind the model

This model is valuable for three reasons.

### 1. It preserves depth
Nothing important needs to be deleted. Rich capability can stay.

### 2. It reduces confusion
The agent can learn one concept once, not three slightly different copies.

### 3. It attacks the real token leak
The largest waste is not just large files. It is repeated retrieval of near-identical content.

## Anti-patterns

### Anti-pattern A: package path determines truth
Filesystem location alone should not define authority.

### Anti-pattern B: every target projection is equally retrievable
That inflates results and encourages target drift.

### Anti-pattern C: knowledgebase export mirrors install surface
A KB export should be optimized for retrieval, not for reproducing the package tree exactly.

### Anti-pattern D: duplicate suppression based only on exact hashes
Near-duplicate prose often causes almost as much waste as exact copies.

## Acceptance criteria

This model is successful when:
1. repeated retrieval results drop materially
2. canonical bodies are surfaced first
3. wrappers stay small
4. `kb-lean` exports are measurably smaller
5. generated projections no longer dominate search results
6. the platform still preserves deep runtime capabilities

## Final design statement

The filesystem can contain many representations.  
The retrieval system should still present one authoritative concept.


---


# Output Token Policy and Response Profiles

## Purpose

Define how Harness Forge should reduce output-token spending without making results vague, shallow, or unusable.

## Problem statement

Large systems with multi-step reasoning can waste tokens in two directions:

1. **Input-side waste**  
   Too much context is loaded or repeated before reasoning begins.

2. **Output-side waste**  
   The system emits long, repetitive prose at every step, even when only a short delta is needed.

This document focuses on the second problem.

## Core position

Output brevity should not mean lower quality.  
It should mean stronger structure, better defaults, and less repeated narrative.

## Guiding rule

The default result should be the smallest output that still lets the next actor make the correct next decision.

That "next actor" may be:
- an operator
- a top-level orchestrator
- a recursive worker
- a follow-up automation
- a release or review gate

## Main design move

Separate **machine output contracts** from **human narrative contracts**.

Inner loops should emit compact structured results.  
Human-facing synthesis should happen once, at the right layer.

## Profiles

Harness Forge should support at least three narrative profiles:

- `brief`
- `standard`
- `deep`

These should apply to reviews, recursive sessions, audits, task summaries, and exported findings.

## Profile definitions

### `brief`

Use when:
- recursive workers are reporting upstream
- machine-to-machine loops dominate
- low-latency high-volume review is required
- only the most important deltas matter

Expected output:
- verdict
- top 1 to 3 findings
- evidence paths
- next action
- confidence or severity
- no narrative restatement unless required

Example:

```json
{
  "verdict": "changes-requested",
  "findings": [
    {
      "severity": "high",
      "title": "duplicate canonical skill body",
      "evidence": [".agents/skills/x/SKILL.md", ".hforge/library/skills/x/SKILL.md"],
      "action": "keep wrapper, trim duplicate body"
    }
  ],
  "nextAction": "rewrite wrapper to canonical pointer format",
  "confidence": "high"
}
```

### `standard`

Use when:
- direct operator interaction is happening
- a human needs explanation, but not a full essay
- the result should be readable and actionable in one pass

Expected output:
- overall verdict
- top issues grouped by priority
- short explanation of why
- next actions
- optional pointer to artifacts for depth

Standard should be the default human-facing profile.

### `deep`

Use when:
- signoff or handoff requires detail
- release or governance work needs traceability
- architecture trade-offs must be fully recorded
- the user explicitly asks for depth

Expected output:
- structured summary
- detailed rationale
- comprehensive findings
- trade-offs and alternatives
- references to artifacts
- optional expanded examples

Deep should be opt-in by default.

## Recommended defaults

### Top-level agent to operator
Default: `standard`

Why:
The operator usually needs enough context to trust the result and act, but not a giant report every time.

### Recursive worker to orchestrator
Default: `brief`

Why:
This is where uncontrolled token growth often happens.

### Release signoff / export / audit
Default: `standard`, upgradeable to `deep`

Why:
Many signoff flows need detail, but not always maximum detail.

## Requirements

### R1. Every major output surface must support profiles

At minimum:
- `review`
- `audit`
- `doctor`
- `recursive run`
- `task inspect`
- `export`
- runtime reporting and summaries

### R2. Profiles must be explicit in runtime state

The runtime should record:
- selected profile
- default profile by actor and workflow
- max findings
- max output tokens
- whether delta mode is active

### R3. Delta mode must exist

Most repeated output is repeated context, not new insight.

**Requirement:** Harness Forge should support `delta-only` or equivalent output for iterative flows.

Delta output should emphasize:
- what changed
- what matters now
- what is blocked
- what to do next
- where the full artifact lives

### R4. Inner loops should avoid prose duplication

Recursive or machine loops should prefer structured compact outputs over long prose paragraphs.

### R5. Artifact-backed reporting should be standard

Long detail should go into runtime artifacts or exported documents. Chat or terminal summaries should stay thinner.

## Structured machine contract

Inner-loop outputs should look more like typed records than essays.

Suggested schema:

```json
{
  "profile": "brief",
  "verdict": "pass|warn|fail|changes-requested",
  "summary": "one-line status",
  "findings": [
    {
      "id": "F-001",
      "severity": "low|medium|high|critical",
      "title": "string",
      "why": "short reason",
      "evidence": ["path or artifact id"],
      "recommendation": "small action"
    }
  ],
  "metrics": {
    "filesTouched": 0,
    "duplicateGroups": 0,
    "estimatedSavedTokens": 0
  },
  "nextAction": "string",
  "artifactRefs": ["string"]
}
```

This keeps outputs compact and composable.

## Human narrative contract

The human-facing layer should render from structured results and add:
- prioritization
- reasoning
- trade-offs
- confidence explanation
- selective examples
- concise next steps

But it should not repeat the full background every time.

## Token budget controls

Harness Forge should add output budget controls such as:
- `maxOutputTokens`
- `maxFindings`
- `maxExamples`
- `includeRationale`
- `includeAlternatives`
- `deltaOnly`
- `artifactFirst`

These can be mapped by profile.

Example:

```json
{
  "profiles": {
    "brief": {
      "maxOutputTokens": 300,
      "maxFindings": 3,
      "includeRationale": "minimal",
      "includeAlternatives": false,
      "deltaOnly": true
    },
    "standard": {
      "maxOutputTokens": 900,
      "maxFindings": 7,
      "includeRationale": "moderate",
      "includeAlternatives": true,
      "deltaOnly": false
    },
    "deep": {
      "maxOutputTokens": 3000,
      "maxFindings": 15,
      "includeRationale": "full",
      "includeAlternatives": true,
      "deltaOnly": false
    }
  }
}
```

## Review-specific policy

A good review does not need to narrate everything.

### Recommended review structure
1. verdict
2. top findings only
3. why they matter
4. next change or command
5. optional artifact reference

### Example: `brief` review

```md
Verdict: changes requested

High priority
- duplicate retrieval risk between wrapper and canonical skill body
- target bridge exceeds hot-path size budget

Next step
- convert wrapper to pointer format
- move long explanation into canonical runtime doc
```

### Example: `standard` review

```md
Verdict: changes requested

Main issue
The current target bridge duplicates too much canonical guidance, which increases first-hop token load and increases the chance of repeated retrieval.

Why it matters
That wastes tokens in both orientation and review loops, and makes it harder for an agent to know which copy is authoritative.

Suggested fix
Trim the bridge to a discovery wrapper and move the long body into the canonical `.hforge` surface.
```

## Recursive workflow policy

Recursive workflows are especially dangerous for output spend, because they create nested narrative loops.

### Recommended rule
- worker agents default to `brief`
- orchestrator can request `standard` when synthesis is needed
- final user-facing answer defaults to `standard`
- `deep` is opt-in or policy-triggered

### Example
A recursive code review with 12 workers should not produce 12 essays. It should produce:
- 12 brief records
- one orchestrator synthesis
- one optional deep artifact

## Artifact-first reporting

Long detail should be stored in artifacts, not repeated into every response.

Examples:
- `.hforge/runtime/reviews/<id>.json`
- `.hforge/runtime/reviews/<id>.md`
- `.hforge/runtime/recursive/sessions/<id>/runs/<runId>.json`
- exported markdown or zip bundles

Then the terminal or chat output can say:
- verdict
- top issues
- artifact path

This is much cheaper than streaming the full detail every time.

## Requirements for command surfaces

Every reporting command should support:
- `--brief`
- `--standard`
- `--deep`
- `--delta-only`
- `--summary-only`
- `--max-findings <n>`

Optional but valuable:
- `--artifact-first`
- `--max-output-tokens <n>`

## Requirements for runtime policy files

The runtime should be able to store default policy in a machine-readable form.

Suggested file:
- `.hforge/runtime/output-policy.json`

Suggested responsibilities:
- global defaults
- actor-based defaults
- workflow-based overrides
- hard caps
- audit thresholds
- command-to-profile mappings

## Reasoning behind the policy

### 1. The most expensive output is repeated explanation
Many systems do not spend most of their output tokens on genuinely new reasoning. They spend them on reintroducing context or narrating the same structure again.

### 2. Humans and machines need different verbosity
A recursive worker does not need to sound polished. It needs to be correct, compact, and composable.

### 3. Good structure improves quality
Shorter output with stronger prioritization often feels smarter, not weaker.

### 4. Artifacts preserve depth without polluting the loop
You can keep rich depth in files while keeping the conversational surface lean.

## Anti-patterns

### Anti-pattern A: every step writes a mini-report
This is the classic token sink.

### Anti-pattern B: one default verbosity for every actor
Different workflows have different needs.

### Anti-pattern C: brief mode that hides actionable evidence
Brevity is not an excuse for dropping evidence or next actions.

### Anti-pattern D: deep mode as the implicit default
Deep should be a choice, not a silent tax.

## Acceptance criteria

This policy is successful when:
1. worker outputs become materially smaller
2. operator-facing answers remain useful
3. repeated narrative drops
4. delta mode is adopted for iterative loops
5. detail moves into runtime artifacts instead of chat
6. output profiles are consistent across commands and target surfaces

## Final design statement

The cheapest good answer is not the shortest answer.  
It is the answer that contains only the information needed for the next correct move.


---


# Multi-Target Bridge Specification

## Purpose

Define how Harness Forge should support `AGENTS.md`, `CLAUDE.md`, Codex-style proprietary surfaces, and future target-specific formats without fragmenting the canonical runtime or multiplying duplicated text.

## Problem statement

Multi-target support creates a predictable risk:

- every target wants its own visible integration surface
- every surface is tempted to become "the real instructions"
- duplicated instructions drift over time
- retrieval becomes noisy
- target support claims become overstated or inconsistent

Harness Forge already has the right directional pattern: thin visible bridge surfaces and a shared hidden runtime. This document turns that into a formal multi-target contract.

## Core thesis

Targets should have native bridges.  
The runtime should still have one canonical center.

That means:
- target-native surface where needed
- shared runtime beneath
- consistent authority model
- target-specific projections only when necessary
- bridge size discipline

## Scope

This spec covers:
- `AGENTS.md`
- `CLAUDE.md`
- Codex-style files such as `.codex/config.toml`
- target adapter manifests
- future proprietary bridge formats

This spec does not require every target to support every capability natively. It requires honest mapping and clear fallback behavior.

## Terminology

### Bridge surface
The file or folder a target naturally reads first.

Examples:
- `AGENTS.md`
- `CLAUDE.md`
- `.codex/config.toml`
- a future vendor-specific instruction file

### Shared runtime
The hidden canonical layer under `.hforge/` that contains the real skills, rules, knowledge, templates, and runtime state.

### Adapter
The target-specific mapping definition that explains:
- what paths get installed
- what target features are supported
- which bridges exist
- how shared runtime is exposed
- what is native versus translated

### Projection
A target-specific emitted artifact derived from shared runtime content.

## Design principles

### P1. Native where necessary, shared where possible
A target should get the file shape it expects, but the content should still point into shared canonical runtime.

### P2. Thin bridges
Bridge files should orient, map, and constrain. They should not become second canonical bodies.

### P3. Honest capability claims
If a target only supports translated or bridged behavior, the platform must say so.

### P4. Same concept, multiple shapes
The same runtime concept may appear as:
- markdown bridge
- JSON adapter entry
- TOML config hint
- generated launcher
- target-native template pointer

But it should still resolve to one canonical concept.

## Requirements

### R1. Every target must have an adapter contract

Each target should define:
- target ID
- display name
- install root strategy
- path mappings
- merge rules
- capability flags
- shared runtime bridge metadata
- authoritative surfaces
- visible bridge paths
- support mode notes

### R2. Bridge files must point inward

Target bridges must explicitly point to shared runtime roots and canonical authority paths.

They should answer:
- where canonical skills live
- where rules live
- where knowledge lives
- where templates live
- where runtime findings live
- which target-specific files are only bridges

### R3. Target-specific files must not overtake canonical bodies

A `CLAUDE.md` or Codex config should not silently become the real canonical skill library. It should remain a bridge or projection unless the architecture explicitly says otherwise.

### R4. Install-time projections should be traceable

If content is emitted into target-specific folders, those files should declare:
- origin concept
- origin path
- target ID
- canonicality status
- projection type

### R5. Merge behavior must be explicit

Targets differ. Some may want copy semantics, some append-once, some generated managed blocks.

The adapter contract must declare merge rules rather than relying on ad hoc installer behavior.

## Bridge model by target

## `AGENTS.md`

### Role
Cross-target, human-readable first bridge. Useful for both humans and some agents.

### Recommended content
- what Harness Forge is doing in this workspace
- thin explanation of `.hforge` as canonical runtime
- discovery-first load order
- trust/scope rules
- command catalog pointer
- runtime state pointer
- warning that target-specific visible files are bridges, not the canonical knowledgebase

### Must not become
- a full mirror of all skills
- a full rules encyclopedia
- a giant historical design document

## `CLAUDE.md`

### Role
Claude-native bridge surface.

### Recommended content
- concise target-specific bootstrapping notes
- pointer to `.hforge` authority
- pointer to `.agents/skills`
- pointer to `.claude/settings.json` or hooks if relevant
- clear statement about visible versus canonical layers

### Must not become
- a second full AGENTS body
- a copy of all runtime guidance
- a maintainer provenance archive

## Codex-style proprietary surface

Codex-style support often wants a vendor-native configuration surface such as `.codex/config.toml`.

### Role
Machine-oriented target bridge with small configuration and clear pointer into the shared runtime.

### Recommended content
- target configuration
- pointer to `AGENTS.md`
- pointer to `.agents/skills`
- pointer to `.hforge/runtime/*`
- enablement of target-appropriate templates or defaults

### Must not become
- a full prose instruction novel
- an unmanaged alternate runtime
- a target-specific replacement for `.hforge`

## Future proprietary formats

Harness Forge should be able to support future formats by introducing a new adapter without rewriting the canonical runtime architecture.

### Requirement
The adapter abstraction must be general enough for:
- markdown instruction files
- TOML or YAML config
- JSON config
- directory-based target bundles
- launcher or plugin projections

## Generic target adapter schema

```json
{
  "id": "target-id",
  "displayName": "Target Name",
  "installRootStrategy": "repo-root",
  "pathMappings": {},
  "mergeRules": {},
  "supportsHooks": false,
  "supportsCommands": true,
  "supportsAgents": true,
  "supportsContexts": true,
  "supportsPlugins": false,
  "sharedRuntimeBridge": {
    "instructionSurfaces": [],
    "runtimeSurfaces": [],
    "supportMode": "native|translated|bridged|partial",
    "authoritativeSurfaces": [],
    "visibleBridgePaths": [],
    "visibilityMode": "hidden-ai-layer"
  },
  "guidanceTemplate": "target-template-id"
}
```

## Path mapping strategy

Path mappings should distinguish between:
- visible bridge install paths
- target-native runtime directories
- shared runtime canonical paths
- template projections

### Example pattern
- canonical source: `targets/codex/runtime/.codex`
- installed bridge path: `.codex`
- canonical shared runtime: `.hforge/*`

## Merge rule strategy

Recommended merge modes:
- `copy`
- `append-once`
- `managed-block`
- `merge-json-object`
- `merge-toml-table`
- `preserve-user-sections`

This avoids target installers inventing behavior on the fly.

## Target capability honesty

Not all targets support:
- hooks
- plugins
- recursive execution
- native agent directories
- runtime-native commands
- context files
- validation workflows

The adapter must be explicit about:
- native support
- translated support
- bridged support
- unsupported support

### Why this matters
Capability overclaiming creates false trust and bad prompting. An agent or operator should be able to tell whether a feature is:
- truly native
- approximated
- only documented
- unavailable

## Bridge size policy

Each bridge type should have a budget.

Suggested policy:
- `AGENTS.md`: concise but sufficient
- `CLAUDE.md`: even thinner if it mostly points to shared runtime
- `.codex/config.toml`: minimal and machine-oriented
- target-specific template projections: only what the target needs

This ensures multi-target support does not multiply hot-path size.

## Example architecture

### Installed workspace
- `AGENTS.md`
- `CLAUDE.md` or `.codex/config.toml`
- `.agents/skills/*`
- `.hforge/library/*`
- `.hforge/runtime/*`
- target-native runtime folder if required

### Behavior
1. target reads native bridge
2. bridge points to shared runtime
3. target-specific projection activates target-native behaviors
4. canonical execution contracts remain in `.hforge`

## Example: `AGENTS.md` bridge

```md
# Workspace guidance

Treat `.hforge/` as the canonical AI/runtime layer.

Load order
1. `.hforge/agent-manifest.json`
2. `.hforge/runtime/index.json`
3. `.hforge/runtime/authority-map.json`
4. `.hforge/runtime/context-budget.json`

Discovery bridges
- `.agents/skills/`
- target-native files such as `CLAUDE.md` or `.codex/config.toml`

Do not treat visible bridges as separate canonical knowledge systems.
```

## Example: `CLAUDE.md` bridge

```md
# Claude workspace bridge

Use the shared `.hforge/` runtime as canonical.

Read first
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`

Discovery paths
- `.agents/skills/`
- `.claude/settings.json`

Visible target files are bridges into the shared runtime, not separate authoritative systems.
```

## Example: Codex-style TOML bridge

```toml
# Codex runtime bridge

[discovery]
agents = "AGENTS.md"
skills = ".agents/skills"
runtime_index = ".hforge/runtime/index.json"
authority_map = ".hforge/runtime/authority-map.json"
context_budget = ".hforge/runtime/context-budget.json"

[mode]
shared_runtime = true
visibility = "hidden-ai-layer"
```

## Examples of supported target behavior modes

### Native
The target can directly use the projected surface with minimal translation.

### Bridged
The target can discover and use the surface, but some behavior is mediated through the shared runtime rather than the target itself.

### Translated
The target cannot do the behavior natively, but Harness Forge can translate the capability into a form the target can still consume.

### Partial
Only some parts are supported. The adapter must say which.

## Requirements for future-proofing

To support "any Codex proprietary format" or future vendor-specific formats, the system should avoid hardcoding target logic into canonical documents.

Instead:
- define canonical concepts once
- define adapter mappings per target
- emit target projections from adapters
- preserve one shared runtime core

## Anti-patterns

### Anti-pattern A: every target gets a full cloned guidance body
This multiplies drift and hot-path size.

### Anti-pattern B: target file contains more truth than canonical runtime
That inverts the architecture.

### Anti-pattern C: target claims are inferred from docs instead of adapter metadata
Support posture should be explicit and machine-readable.

### Anti-pattern D: install output hides provenance
Projections should remain traceable back to the canonical concept.

## Acceptance criteria

This spec is successful when:
1. `AGENTS.md`, `CLAUDE.md`, and Codex-style surfaces all work as native bridges
2. canonical truth still lives in one shared runtime
3. target projections stay thin and traceable
4. capability claims stay honest
5. multi-target support does not inflate first-hop prompt cost
6. future target formats can be added via adapters instead of architectural rewrites

## Final design statement

A good target bridge feels native to the target.  
A good runtime still has one canonical center.


---


# Rollout Plan, Validation, and CI Gates

## Purpose

Define how to move from the current broad package surface toward a cleaner runtime-native, deduped, multi-target architecture without breaking capability or operator workflows.

## Rollout philosophy

Do not attempt a giant rewrite.  
Introduce metadata, budgets, and stratification first.  
Then reduce duplication and tighten retrieval behavior incrementally.

This is safer because Harness Forge already has strong runtime concepts. The problem is placement and discipline, not the absence of capability.

## Rollout stages

## Stage 0: Observe the current surface

### Goals
- quantify hot-path size
- inventory duplicate concepts
- identify giant wrappers
- identify generated surfaces leaking into retrieval
- establish baseline token spend

### Deliverables
- duplicate inventory report
- wrapper size report
- first-hop load estimate
- retrieval noise report
- cold-surface leakage report

### Requirements
Build or expose:
- `hforge token audit --json`
- `hforge duplicate audit --json`
- `hforge surface tiers --json`
- `hforge export --kb-lean --dry-run`

## Stage 1: Add authority and budget metadata

### Goals
- encode canonicality explicitly
- define tiers explicitly
- define output profiles explicitly
- avoid behavioral change before observability exists

### Deliverables
- `.hforge/runtime/authority-map.json`
- `.hforge/runtime/context-budget.json`
- `.hforge/runtime/output-policy.json`
- concept IDs and alias metadata

### Why this stage matters
Without metadata, later deduplication and export policy become guessy and fragile.

## Stage 2: Shrink wrappers and bridges

### Goals
- convert large wrappers into pointer-first discovery surfaces
- keep target-native support
- reduce repeated retrievals

### Deliverables
- trimmed `.agents/skills/*` wrappers
- trimmed target bridges
- target projections marked as alias or projection
- explicit merge-rule handling

### Success criteria
- bridge token count falls materially
- wrappers no longer dominate retrieval
- operator discoverability remains intact

## Stage 3: Introduce tier-aware retrieval and export profiles

### Goals
- keep rich capability, but move it out of the hot path
- create `kb-lean` as a real first-class export
- exclude cold surfaces by default

### Deliverables
- `kb-lean` export profile
- `runtime-minimal`, `runtime-standard`, `maintainer-full`
- retrieval filters using canonicality and tier metadata

## Stage 4: Enforce output profiles and delta mode

### Goals
- make worker loops cheaper
- standardize human-facing summaries
- keep deep detail artifact-backed

### Deliverables
- profile support on review and recursive commands
- runtime policy defaults
- artifact-first output mode
- delta-only support

## Stage 5: Tighten CI gates

### Goals
- stop regression
- make token discipline part of release quality

### Deliverables
- CI checks
- size budgets
- duplicate thresholds
- bridge limits
- export validation

## Suggested CI gates

### Gate 1: Hot-path budget
Fail when:
- combined first-hop orientation pack exceeds budget
- `AGENTS.md` exceeds configured threshold
- target bridge files exceed target-specific thresholds

### Gate 2: Canonicality completeness
Fail when:
- concept lacks canonical path
- multiple canonical bodies exist
- alias points to missing concept
- generated projection lacks traceability

### Gate 3: Duplicate surface control
Warn or fail when:
- exact duplicate groups exceed threshold
- near-duplicate clusters exceed threshold
- duplicate token estimate grows release-over-release

### Gate 4: Wrapper size discipline
Warn or fail when:
- discovery wrapper exceeds budget
- target bridge embeds too much long-form canonical guidance

### Gate 5: Cold-surface leakage
Fail when:
- temp or coverage content leaks into `kb-lean`
- cold surfaces are marked as hot
- provenance shows up in default retrieval exports

### Gate 6: Output-profile support
Fail when:
- key reporting commands lack `brief` and `standard`
- recursive workflows default to verbose mode
- delta mode is missing for iterative commands

### Gate 7: Target capability honesty
Fail when:
- target docs or adapter claim support inconsistent with capability matrix
- a target projection suggests native support where only bridging exists

## Suggested commands

### Auditing and analysis
- `hforge token audit --root . --json`
- `hforge duplicate audit --root . --json`
- `hforge surface tiers --root . --json`
- `hforge target inspect <target> --json`

### Policy and budgeting
- `hforge token budget --root . --profile runtime-standard --json`
- `hforge output policy --root . --json`

### Export
- `hforge export --kb-lean --root .`
- `hforge export --runtime-minimal --root .`
- `hforge export --maintainer-full --root .`

### Review/reporting
- `hforge review --brief`
- `hforge review --standard`
- `hforge review --deep`
- `hforge recursive run ... --brief`
- `hforge recursive run ... --delta-only`

## Example acceptance test matrix

## Architecture tests
- fresh agent can orient from first-hop pack only
- operator can still discover commands directly
- target bridges remain functional after wrapper shrinking

## Retrieval tests
- canonical body is returned before alias duplicates
- exact duplicates are suppressed
- near duplicates are demoted
- cold provenance is excluded by default

## Output tests
- recursive worker output is compact
- operator-facing review remains understandable
- delta mode only emits changes
- artifact-backed detail is still reachable

## Export tests
- `kb-lean` excludes temp, coverage, cold provenance
- canonical bodies remain present
- target adapter definitions remain present
- exported size is materially smaller than full surface

## Metrics to track

### Token metrics
- estimated first-hop tokens
- estimated `kb-lean` tokens
- duplicated token estimate
- worker output median tokens
- operator output median tokens

### Retrieval metrics
- average duplicate result count per query
- canonical-first retrieval rate
- cold-surface leakage rate
- near-duplicate suppression rate

### UX metrics
- successful agent orientation without CLI
- operator time-to-first-useful-command
- review usefulness score
- false capability claim incidents

## Reasoning behind staged rollout

### 1. Metadata before deletion
If you cut surfaces before encoding authority, the platform becomes brittle.

### 2. Visibility before enforcement
Teams accept hard gates more easily when baseline reports already exist.

### 3. Thin wrappers before deep refactoring
Bridge trimming often buys a lot of value quickly.

### 4. Export profiles create leverage
Once `kb-lean` exists, the platform can support full maintainers and lean retrieval users at the same time.

## Risks and mitigations

### Risk: bridge trimming harms discoverability
Mitigation:
- keep purpose, use-when, canonical path, and load hints
- validate with orientation tests

### Risk: metadata gets stale
Mitigation:
- generate portions where possible
- add CI for consistency
- tie concept metadata to manifests

### Risk: target support becomes inconsistent
Mitigation:
- adapter contracts remain authoritative
- capability matrix validation remains mandatory

### Risk: output brevity feels too terse
Mitigation:
- use `standard` as default for human-facing top-level flows
- keep `deep` opt-in
- store detail in artifacts

## Minimal viable implementation order

If only a small amount can be done first, do this:

1. create `authority-map.json`
2. create `context-budget.json`
3. trim wrappers and target bridges
4. add `brief` and `standard`
5. add `kb-lean`
6. add duplicate and hot-path CI gates

That sequence gives the best ratio of benefit to implementation risk.

## Acceptance criteria

The rollout is successful when:
1. hot-path size drops without deleting capability
2. target-native support still works
3. repeated retrievals reduce materially
4. worker output becomes cheaper
5. `kb-lean` becomes usable for knowledgebase uploads
6. CI prevents regression

## Final design statement

A mature runtime is not just feature-rich.  
It is measurable, stratified, and hard to regress.


---


# Example Artifacts and Schemas

## Purpose

Provide concrete example files for the proposed runtime architecture so implementation can start with stable shapes instead of vague ideas.

## Example 1: `.hforge/runtime/authority-map.json`

```json
{
  "schemaVersion": "1.0.0",
  "generatedAt": "2026-04-03T12:00:00Z",
  "concepts": [
    {
      "conceptId": "runtime.orientation",
      "title": "Workspace orientation",
      "canonicalPath": "AGENTS.md",
      "aliases": ["CLAUDE.md"],
      "surfaceType": "bridge",
      "tier": "hot",
      "indexPriority": "high",
      "reasonToLoad": "First-hop orientation for agents and operators",
      "reasonToAvoid": "Do not treat as full canonical skill body"
    },
    {
      "conceptId": "skill.typescript-engineering",
      "title": "TypeScript Engineering",
      "canonicalPath": ".hforge/library/skills/typescript-engineering/SKILL.md",
      "aliases": [".agents/skills/typescript-engineering/SKILL.md"],
      "projections": ["dist/cli/.hforge/library/skills/typescript-engineering/SKILL.md"],
      "surfaceType": "skill",
      "tier": "warm",
      "indexPriority": "high",
      "reasonToLoad": "TypeScript-heavy implementation or review work",
      "reasonToAvoid": "Avoid first-hop load if task does not involve TypeScript"
    }
  ]
}
```

## Example 2: `.hforge/runtime/context-budget.json`

```json
{
  "schemaVersion": "1.0.0",
  "maxFirstHopTokens": 8000,
  "hotSurfaces": [
    "AGENTS.md",
    ".hforge/agent-manifest.json",
    ".hforge/runtime/index.json",
    ".hforge/runtime/authority-map.json",
    ".hforge/runtime/context-budget.json"
  ],
  "warmSurfaces": [
    ".hforge/generated/agent-command-catalog.json",
    ".hforge/runtime/repo/recommendations.json",
    ".hforge/runtime/repo/repo-map.json",
    ".hforge/library/skills",
    ".hforge/library/rules",
    ".hforge/library/knowledge"
  ],
  "coldSurfaces": [
    ".tmp",
    "coverage",
    "tests",
    "docs/authoring",
    ".hforge/library/docs/authoring"
  ],
  "dropOrder": [
    "coverage",
    ".tmp",
    "tests",
    "docs/authoring",
    "dist"
  ],
  "profiles": {
    "brief": {
      "maxOutputTokens": 300,
      "maxFindings": 3
    },
    "standard": {
      "maxOutputTokens": 900,
      "maxFindings": 7
    },
    "deep": {
      "maxOutputTokens": 3000,
      "maxFindings": 15
    }
  }
}
```

## Example 3: thin `.agents/skills/.../SKILL.md` wrapper

```md
# TypeScript Engineering

Purpose
TypeScript-heavy implementation, refactoring, review, typing, tooling, and boundary design.

Use when
- the repo is TypeScript-heavy
- the task depends on types, contracts, build correctness, or refactoring safety

Canonical contract
- `.hforge/library/skills/typescript-engineering/SKILL.md`

Concept ID
- `skill.typescript-engineering`

Load hint
- skip unless the task actually depends on TypeScript behavior
```

## Example 4: thin `AGENTS.md`

```md
# Workspace guidance

Use visible bridge surfaces first:
- `AGENTS.md`
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`
- `.hforge/generated/agent-command-catalog.json`

Treat `.hforge/` as the canonical AI/runtime layer.

Load order
1. `.hforge/runtime/authority-map.json`
2. `.hforge/runtime/context-budget.json`
3. task-relevant runtime findings and skills

Visible target bridges such as `CLAUDE.md`, `.agents/skills/`, and `.codex/` are discovery surfaces, not separate canonical knowledge systems.
```

## Example 5: `CLAUDE.md`

```md
# Claude workspace bridge

Use the shared `.hforge/` runtime as canonical.

Read first
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`
- `.hforge/runtime/authority-map.json`
- `.hforge/runtime/context-budget.json`

Target-specific surfaces
- `.claude/settings.json`
- `.agents/skills/`

Visible target files are bridges into the shared runtime.
```

## Example 6: `.codex/config.toml`

```toml
[discovery]
agents = "AGENTS.md"
skills = ".agents/skills"
runtime_index = ".hforge/runtime/index.json"
authority_map = ".hforge/runtime/authority-map.json"
context_budget = ".hforge/runtime/context-budget.json"

[shared_runtime]
enabled = true
visibility = "hidden-ai-layer"
canonical_root = ".hforge"
```

## Example 7: output policy

```json
{
  "schemaVersion": "1.0.0",
  "defaults": {
    "topLevelHuman": "standard",
    "recursiveWorker": "brief",
    "releaseSignoff": "standard"
  },
  "profiles": {
    "brief": {
      "maxOutputTokens": 300,
      "maxFindings": 3,
      "deltaOnly": true
    },
    "standard": {
      "maxOutputTokens": 900,
      "maxFindings": 7,
      "deltaOnly": false
    },
    "deep": {
      "maxOutputTokens": 3000,
      "maxFindings": 15,
      "deltaOnly": false
    }
  }
}
```

## Example 8: duplicate inventory report

```json
{
  "generatedAt": "2026-04-03T12:00:00Z",
  "duplicateGroups": [
    {
      "groupId": "dup-001",
      "conceptId": "skill.token-budget-optimizer",
      "canonicalPath": ".hforge/library/skills/token-budget-optimizer/SKILL.md",
      "duplicatePaths": [
        ".agents/skills/token-budget-optimizer/SKILL.md",
        "dist/cli/.hforge/library/skills/token-budget-optimizer/SKILL.md"
      ],
      "duplicateType": "exact",
      "estimatedRepeatedTokens": 1800,
      "recommendedAction": "trim wrapper; mark dist projection cold"
    }
  ]
}
```

## Example 9: `kb-lean` export manifest

```json
{
  "profile": "kb-lean",
  "include": [
    "AGENTS.md",
    ".hforge/agent-manifest.json",
    ".hforge/runtime",
    ".hforge/generated/agent-command-catalog.json",
    ".hforge/library/skills",
    ".hforge/library/rules",
    ".hforge/library/knowledge",
    ".hforge/templates",
    "targets"
  ],
  "exclude": [
    ".tmp",
    "coverage",
    "tests",
    "docs/authoring",
    ".hforge/library/docs/authoring",
    "dist"
  ],
  "notes": "Generated duplicates and cold provenance are excluded by default."
}
```

## Example 10: target adapter with honest support posture

```json
{
  "id": "codex",
  "displayName": "Codex",
  "supportsHooks": false,
  "supportsCommands": true,
  "supportsAgents": true,
  "supportsContexts": true,
  "supportsPlugins": false,
  "sharedRuntimeBridge": {
    "supportMode": "native",
    "instructionSurfaces": [
      "AGENTS.md",
      ".agents/skills",
      ".codex/config.toml"
    ],
    "runtimeSurfaces": [
      ".hforge/runtime/index.json",
      ".hforge/runtime/authority-map.json",
      ".hforge/runtime/context-budget.json"
    ],
    "authoritativeSurfaces": [
      ".hforge/library/skills",
      ".hforge/library/rules",
      ".hforge/library/knowledge",
      ".hforge/templates",
      ".hforge/runtime"
    ]
  }
}
```

## Example 11: compact recursive worker output

```json
{
  "profile": "brief",
  "verdict": "warn",
  "summary": "duplicate wrapper and canonical body increase retrieval fanout",
  "findings": [
    {
      "id": "F-01",
      "severity": "high",
      "title": "wrapper duplicates canonical skill",
      "why": "same concept appears in hot and warm retrieval paths",
      "evidence": [
        ".agents/skills/token-budget-optimizer/SKILL.md",
        ".hforge/library/skills/token-budget-optimizer/SKILL.md"
      ],
      "recommendation": "convert wrapper to pointer-first form"
    }
  ],
  "nextAction": "run duplicate audit after trimming wrappers",
  "artifactRefs": [".hforge/runtime/reviews/review-2026-04-03-001.json"]
}
```

## Example 12: top-level human summary rendered from compact results

```md
Verdict: changes requested

Main issue
The current runtime still exposes the same concept through multiple retrievable paths, which increases both prompt load and review-loop token spend.

Why it matters
Agents can find the same guidance more than once and treat mirrored files as equally authoritative.

Suggested fix
Keep one canonical body under `.hforge/`, convert wrappers into discovery pointers, and move repeated detail into artifact-backed runtime documents.
```

## Suggested naming conventions

- `conceptId`: stable dotted identifier such as `skill.token-budget-optimizer`
- `surfaceType`: `bridge | skill | rule | knowledge | template | runtime-index | projection | provenance`
- `tier`: `hot | warm | cold`
- `supportMode`: `native | bridged | translated | partial`

## Implementation note

These examples are deliberately small. Real implementations can extend them, but the core idea should remain:
- small first-hop surfaces
- explicit authority
- dedup-aware retrieval
- profile-aware output
- target-native bridges over one canonical runtime
