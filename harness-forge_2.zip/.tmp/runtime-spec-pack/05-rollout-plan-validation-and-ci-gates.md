# Rollout Plan, Validation, and CI Gates

## Purpose

Define how to move from the current broad package surface toward a cleaner runtime-native, deduped, multi-target architecture without breaking capability or operator workflows.

## Rollout philosophy

Do not attempt a giant rewrite.  
Introduce metadata, budgets, and stratification first.  
Then reduce duplication and tighten retrieval behavior incrementally.

This is safer because Harness Forge already has strong runtime concepts. The problem is placement and discipline, not the absence of capability.

## Rollout stages

## Stage 0: Observe the current surface

### Goals
- quantify hot-path size
- inventory duplicate concepts
- identify giant wrappers
- identify generated surfaces leaking into retrieval
- establish baseline token spend

### Deliverables
- duplicate inventory report
- wrapper size report
- first-hop load estimate
- retrieval noise report
- cold-surface leakage report

### Requirements
Build or expose:
- `hforge token audit --json`
- `hforge duplicate audit --json`
- `hforge surface tiers --json`
- `hforge export --kb-lean --dry-run`

## Stage 1: Add authority and budget metadata

### Goals
- encode canonicality explicitly
- define tiers explicitly
- define output profiles explicitly
- avoid behavioral change before observability exists

### Deliverables
- `.hforge/runtime/authority-map.json`
- `.hforge/runtime/context-budget.json`
- `.hforge/runtime/output-policy.json`
- concept IDs and alias metadata

### Why this stage matters
Without metadata, later deduplication and export policy become guessy and fragile.

## Stage 2: Shrink wrappers and bridges

### Goals
- convert large wrappers into pointer-first discovery surfaces
- keep target-native support
- reduce repeated retrievals

### Deliverables
- trimmed `.agents/skills/*` wrappers
- trimmed target bridges
- target projections marked as alias or projection
- explicit merge-rule handling

### Success criteria
- bridge token count falls materially
- wrappers no longer dominate retrieval
- operator discoverability remains intact

## Stage 3: Introduce tier-aware retrieval and export profiles

### Goals
- keep rich capability, but move it out of the hot path
- create `kb-lean` as a real first-class export
- exclude cold surfaces by default

### Deliverables
- `kb-lean` export profile
- `runtime-minimal`, `runtime-standard`, `maintainer-full`
- retrieval filters using canonicality and tier metadata

## Stage 4: Enforce output profiles and delta mode

### Goals
- make worker loops cheaper
- standardize human-facing summaries
- keep deep detail artifact-backed

### Deliverables
- profile support on review and recursive commands
- runtime policy defaults
- artifact-first output mode
- delta-only support

## Stage 5: Tighten CI gates

### Goals
- stop regression
- make token discipline part of release quality

### Deliverables
- CI checks
- size budgets
- duplicate thresholds
- bridge limits
- export validation

## Suggested CI gates

### Gate 1: Hot-path budget
Fail when:
- combined first-hop orientation pack exceeds budget
- `AGENTS.md` exceeds configured threshold
- target bridge files exceed target-specific thresholds

### Gate 2: Canonicality completeness
Fail when:
- concept lacks canonical path
- multiple canonical bodies exist
- alias points to missing concept
- generated projection lacks traceability

### Gate 3: Duplicate surface control
Warn or fail when:
- exact duplicate groups exceed threshold
- near-duplicate clusters exceed threshold
- duplicate token estimate grows release-over-release

### Gate 4: Wrapper size discipline
Warn or fail when:
- discovery wrapper exceeds budget
- target bridge embeds too much long-form canonical guidance

### Gate 5: Cold-surface leakage
Fail when:
- temp or coverage content leaks into `kb-lean`
- cold surfaces are marked as hot
- provenance shows up in default retrieval exports

### Gate 6: Output-profile support
Fail when:
- key reporting commands lack `brief` and `standard`
- recursive workflows default to verbose mode
- delta mode is missing for iterative commands

### Gate 7: Target capability honesty
Fail when:
- target docs or adapter claim support inconsistent with capability matrix
- a target projection suggests native support where only bridging exists

## Suggested commands

### Auditing and analysis
- `hforge token audit --root . --json`
- `hforge duplicate audit --root . --json`
- `hforge surface tiers --root . --json`
- `hforge target inspect <target> --json`

### Policy and budgeting
- `hforge token budget --root . --profile runtime-standard --json`
- `hforge output policy --root . --json`

### Export
- `hforge export --kb-lean --root .`
- `hforge export --runtime-minimal --root .`
- `hforge export --maintainer-full --root .`

### Review/reporting
- `hforge review --brief`
- `hforge review --standard`
- `hforge review --deep`
- `hforge recursive run ... --brief`
- `hforge recursive run ... --delta-only`

## Example acceptance test matrix

## Architecture tests
- fresh agent can orient from first-hop pack only
- operator can still discover commands directly
- target bridges remain functional after wrapper shrinking

## Retrieval tests
- canonical body is returned before alias duplicates
- exact duplicates are suppressed
- near duplicates are demoted
- cold provenance is excluded by default

## Output tests
- recursive worker output is compact
- operator-facing review remains understandable
- delta mode only emits changes
- artifact-backed detail is still reachable

## Export tests
- `kb-lean` excludes temp, coverage, cold provenance
- canonical bodies remain present
- target adapter definitions remain present
- exported size is materially smaller than full surface

## Metrics to track

### Token metrics
- estimated first-hop tokens
- estimated `kb-lean` tokens
- duplicated token estimate
- worker output median tokens
- operator output median tokens

### Retrieval metrics
- average duplicate result count per query
- canonical-first retrieval rate
- cold-surface leakage rate
- near-duplicate suppression rate

### UX metrics
- successful agent orientation without CLI
- operator time-to-first-useful-command
- review usefulness score
- false capability claim incidents

## Reasoning behind staged rollout

### 1. Metadata before deletion
If you cut surfaces before encoding authority, the platform becomes brittle.

### 2. Visibility before enforcement
Teams accept hard gates more easily when baseline reports already exist.

### 3. Thin wrappers before deep refactoring
Bridge trimming often buys a lot of value quickly.

### 4. Export profiles create leverage
Once `kb-lean` exists, the platform can support full maintainers and lean retrieval users at the same time.

## Risks and mitigations

### Risk: bridge trimming harms discoverability
Mitigation:
- keep purpose, use-when, canonical path, and load hints
- validate with orientation tests

### Risk: metadata gets stale
Mitigation:
- generate portions where possible
- add CI for consistency
- tie concept metadata to manifests

### Risk: target support becomes inconsistent
Mitigation:
- adapter contracts remain authoritative
- capability matrix validation remains mandatory

### Risk: output brevity feels too terse
Mitigation:
- use `standard` as default for human-facing top-level flows
- keep `deep` opt-in
- store detail in artifacts

## Minimal viable implementation order

If only a small amount can be done first, do this:

1. create `authority-map.json`
2. create `context-budget.json`
3. trim wrappers and target bridges
4. add `brief` and `standard`
5. add `kb-lean`
6. add duplicate and hot-path CI gates

That sequence gives the best ratio of benefit to implementation risk.

## Acceptance criteria

The rollout is successful when:
1. hot-path size drops without deleting capability
2. target-native support still works
3. repeated retrievals reduce materially
4. worker output becomes cheaper
5. `kb-lean` becomes usable for knowledgebase uploads
6. CI prevents regression

## Final design statement

A mature runtime is not just feature-rich.  
It is measurable, stratified, and hard to regress.
