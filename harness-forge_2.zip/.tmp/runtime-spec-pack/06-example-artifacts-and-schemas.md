# Example Artifacts and Schemas

## Purpose

Provide concrete example files for the proposed runtime architecture so implementation can start with stable shapes instead of vague ideas.

## Example 1: `.hforge/runtime/authority-map.json`

```json
{
  "schemaVersion": "1.0.0",
  "generatedAt": "2026-04-03T12:00:00Z",
  "concepts": [
    {
      "conceptId": "runtime.orientation",
      "title": "Workspace orientation",
      "canonicalPath": "AGENTS.md",
      "aliases": ["CLAUDE.md"],
      "surfaceType": "bridge",
      "tier": "hot",
      "indexPriority": "high",
      "reasonToLoad": "First-hop orientation for agents and operators",
      "reasonToAvoid": "Do not treat as full canonical skill body"
    },
    {
      "conceptId": "skill.typescript-engineering",
      "title": "TypeScript Engineering",
      "canonicalPath": ".hforge/library/skills/typescript-engineering/SKILL.md",
      "aliases": [".agents/skills/typescript-engineering/SKILL.md"],
      "projections": ["dist/cli/.hforge/library/skills/typescript-engineering/SKILL.md"],
      "surfaceType": "skill",
      "tier": "warm",
      "indexPriority": "high",
      "reasonToLoad": "TypeScript-heavy implementation or review work",
      "reasonToAvoid": "Avoid first-hop load if task does not involve TypeScript"
    }
  ]
}
```

## Example 2: `.hforge/runtime/context-budget.json`

```json
{
  "schemaVersion": "1.0.0",
  "maxFirstHopTokens": 8000,
  "hotSurfaces": [
    "AGENTS.md",
    ".hforge/agent-manifest.json",
    ".hforge/runtime/index.json",
    ".hforge/runtime/authority-map.json",
    ".hforge/runtime/context-budget.json"
  ],
  "warmSurfaces": [
    ".hforge/generated/agent-command-catalog.json",
    ".hforge/runtime/repo/recommendations.json",
    ".hforge/runtime/repo/repo-map.json",
    ".hforge/library/skills",
    ".hforge/library/rules",
    ".hforge/library/knowledge"
  ],
  "coldSurfaces": [
    ".tmp",
    "coverage",
    "tests",
    "docs/authoring",
    ".hforge/library/docs/authoring"
  ],
  "dropOrder": [
    "coverage",
    ".tmp",
    "tests",
    "docs/authoring",
    "dist"
  ],
  "profiles": {
    "brief": {
      "maxOutputTokens": 300,
      "maxFindings": 3
    },
    "standard": {
      "maxOutputTokens": 900,
      "maxFindings": 7
    },
    "deep": {
      "maxOutputTokens": 3000,
      "maxFindings": 15
    }
  }
}
```

## Example 3: thin `.agents/skills/.../SKILL.md` wrapper

```md
# TypeScript Engineering

Purpose
TypeScript-heavy implementation, refactoring, review, typing, tooling, and boundary design.

Use when
- the repo is TypeScript-heavy
- the task depends on types, contracts, build correctness, or refactoring safety

Canonical contract
- `.hforge/library/skills/typescript-engineering/SKILL.md`

Concept ID
- `skill.typescript-engineering`

Load hint
- skip unless the task actually depends on TypeScript behavior
```

## Example 4: thin `AGENTS.md`

```md
# Workspace guidance

Use visible bridge surfaces first:
- `AGENTS.md`
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`
- `.hforge/generated/agent-command-catalog.json`

Treat `.hforge/` as the canonical AI/runtime layer.

Load order
1. `.hforge/runtime/authority-map.json`
2. `.hforge/runtime/context-budget.json`
3. task-relevant runtime findings and skills

Visible target bridges such as `CLAUDE.md`, `.agents/skills/`, and `.codex/` are discovery surfaces, not separate canonical knowledge systems.
```

## Example 5: `CLAUDE.md`

```md
# Claude workspace bridge

Use the shared `.hforge/` runtime as canonical.

Read first
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`
- `.hforge/runtime/authority-map.json`
- `.hforge/runtime/context-budget.json`

Target-specific surfaces
- `.claude/settings.json`
- `.agents/skills/`

Visible target files are bridges into the shared runtime.
```

## Example 6: `.codex/config.toml`

```toml
[discovery]
agents = "AGENTS.md"
skills = ".agents/skills"
runtime_index = ".hforge/runtime/index.json"
authority_map = ".hforge/runtime/authority-map.json"
context_budget = ".hforge/runtime/context-budget.json"

[shared_runtime]
enabled = true
visibility = "hidden-ai-layer"
canonical_root = ".hforge"
```

## Example 7: output policy

```json
{
  "schemaVersion": "1.0.0",
  "defaults": {
    "topLevelHuman": "standard",
    "recursiveWorker": "brief",
    "releaseSignoff": "standard"
  },
  "profiles": {
    "brief": {
      "maxOutputTokens": 300,
      "maxFindings": 3,
      "deltaOnly": true
    },
    "standard": {
      "maxOutputTokens": 900,
      "maxFindings": 7,
      "deltaOnly": false
    },
    "deep": {
      "maxOutputTokens": 3000,
      "maxFindings": 15,
      "deltaOnly": false
    }
  }
}
```

## Example 8: duplicate inventory report

```json
{
  "generatedAt": "2026-04-03T12:00:00Z",
  "duplicateGroups": [
    {
      "groupId": "dup-001",
      "conceptId": "skill.token-budget-optimizer",
      "canonicalPath": ".hforge/library/skills/token-budget-optimizer/SKILL.md",
      "duplicatePaths": [
        ".agents/skills/token-budget-optimizer/SKILL.md",
        "dist/cli/.hforge/library/skills/token-budget-optimizer/SKILL.md"
      ],
      "duplicateType": "exact",
      "estimatedRepeatedTokens": 1800,
      "recommendedAction": "trim wrapper; mark dist projection cold"
    }
  ]
}
```

## Example 9: `kb-lean` export manifest

```json
{
  "profile": "kb-lean",
  "include": [
    "AGENTS.md",
    ".hforge/agent-manifest.json",
    ".hforge/runtime",
    ".hforge/generated/agent-command-catalog.json",
    ".hforge/library/skills",
    ".hforge/library/rules",
    ".hforge/library/knowledge",
    ".hforge/templates",
    "targets"
  ],
  "exclude": [
    ".tmp",
    "coverage",
    "tests",
    "docs/authoring",
    ".hforge/library/docs/authoring",
    "dist"
  ],
  "notes": "Generated duplicates and cold provenance are excluded by default."
}
```

## Example 10: target adapter with honest support posture

```json
{
  "id": "codex",
  "displayName": "Codex",
  "supportsHooks": false,
  "supportsCommands": true,
  "supportsAgents": true,
  "supportsContexts": true,
  "supportsPlugins": false,
  "sharedRuntimeBridge": {
    "supportMode": "native",
    "instructionSurfaces": [
      "AGENTS.md",
      ".agents/skills",
      ".codex/config.toml"
    ],
    "runtimeSurfaces": [
      ".hforge/runtime/index.json",
      ".hforge/runtime/authority-map.json",
      ".hforge/runtime/context-budget.json"
    ],
    "authoritativeSurfaces": [
      ".hforge/library/skills",
      ".hforge/library/rules",
      ".hforge/library/knowledge",
      ".hforge/templates",
      ".hforge/runtime"
    ]
  }
}
```

## Example 11: compact recursive worker output

```json
{
  "profile": "brief",
  "verdict": "warn",
  "summary": "duplicate wrapper and canonical body increase retrieval fanout",
  "findings": [
    {
      "id": "F-01",
      "severity": "high",
      "title": "wrapper duplicates canonical skill",
      "why": "same concept appears in hot and warm retrieval paths",
      "evidence": [
        ".agents/skills/token-budget-optimizer/SKILL.md",
        ".hforge/library/skills/token-budget-optimizer/SKILL.md"
      ],
      "recommendation": "convert wrapper to pointer-first form"
    }
  ],
  "nextAction": "run duplicate audit after trimming wrappers",
  "artifactRefs": [".hforge/runtime/reviews/review-2026-04-03-001.json"]
}
```

## Example 12: top-level human summary rendered from compact results

```md
Verdict: changes requested

Main issue
The current runtime still exposes the same concept through multiple retrievable paths, which increases both prompt load and review-loop token spend.

Why it matters
Agents can find the same guidance more than once and treat mirrored files as equally authoritative.

Suggested fix
Keep one canonical body under `.hforge/`, convert wrappers into discovery pointers, and move repeated detail into artifact-backed runtime documents.
```

## Suggested naming conventions

- `conceptId`: stable dotted identifier such as `skill.token-budget-optimizer`
- `surfaceType`: `bridge | skill | rule | knowledge | template | runtime-index | projection | provenance`
- `tier`: `hot | warm | cold`
- `supportMode`: `native | bridged | translated | partial`

## Implementation note

These examples are deliberately small. Real implementations can extend them, but the core idea should remain:
- small first-hop surfaces
- explicit authority
- dedup-aware retrieval
- profile-aware output
- target-native bridges over one canonical runtime
