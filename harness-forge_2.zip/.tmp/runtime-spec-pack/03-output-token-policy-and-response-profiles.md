# Output Token Policy and Response Profiles

## Purpose

Define how Harness Forge should reduce output-token spending without making results vague, shallow, or unusable.

## Problem statement

Large systems with multi-step reasoning can waste tokens in two directions:

1. **Input-side waste**  
   Too much context is loaded or repeated before reasoning begins.

2. **Output-side waste**  
   The system emits long, repetitive prose at every step, even when only a short delta is needed.

This document focuses on the second problem.

## Core position

Output brevity should not mean lower quality.  
It should mean stronger structure, better defaults, and less repeated narrative.

## Guiding rule

The default result should be the smallest output that still lets the next actor make the correct next decision.

That "next actor" may be:
- an operator
- a top-level orchestrator
- a recursive worker
- a follow-up automation
- a release or review gate

## Main design move

Separate **machine output contracts** from **human narrative contracts**.

Inner loops should emit compact structured results.  
Human-facing synthesis should happen once, at the right layer.

## Profiles

Harness Forge should support at least three narrative profiles:

- `brief`
- `standard`
- `deep`

These should apply to reviews, recursive sessions, audits, task summaries, and exported findings.

## Profile definitions

### `brief`

Use when:
- recursive workers are reporting upstream
- machine-to-machine loops dominate
- low-latency high-volume review is required
- only the most important deltas matter

Expected output:
- verdict
- top 1 to 3 findings
- evidence paths
- next action
- confidence or severity
- no narrative restatement unless required

Example:

```json
{
  "verdict": "changes-requested",
  "findings": [
    {
      "severity": "high",
      "title": "duplicate canonical skill body",
      "evidence": [".agents/skills/x/SKILL.md", ".hforge/library/skills/x/SKILL.md"],
      "action": "keep wrapper, trim duplicate body"
    }
  ],
  "nextAction": "rewrite wrapper to canonical pointer format",
  "confidence": "high"
}
```

### `standard`

Use when:
- direct operator interaction is happening
- a human needs explanation, but not a full essay
- the result should be readable and actionable in one pass

Expected output:
- overall verdict
- top issues grouped by priority
- short explanation of why
- next actions
- optional pointer to artifacts for depth

Standard should be the default human-facing profile.

### `deep`

Use when:
- signoff or handoff requires detail
- release or governance work needs traceability
- architecture trade-offs must be fully recorded
- the user explicitly asks for depth

Expected output:
- structured summary
- detailed rationale
- comprehensive findings
- trade-offs and alternatives
- references to artifacts
- optional expanded examples

Deep should be opt-in by default.

## Recommended defaults

### Top-level agent to operator
Default: `standard`

Why:
The operator usually needs enough context to trust the result and act, but not a giant report every time.

### Recursive worker to orchestrator
Default: `brief`

Why:
This is where uncontrolled token growth often happens.

### Release signoff / export / audit
Default: `standard`, upgradeable to `deep`

Why:
Many signoff flows need detail, but not always maximum detail.

## Requirements

### R1. Every major output surface must support profiles

At minimum:
- `review`
- `audit`
- `doctor`
- `recursive run`
- `task inspect`
- `export`
- runtime reporting and summaries

### R2. Profiles must be explicit in runtime state

The runtime should record:
- selected profile
- default profile by actor and workflow
- max findings
- max output tokens
- whether delta mode is active

### R3. Delta mode must exist

Most repeated output is repeated context, not new insight.

**Requirement:** Harness Forge should support `delta-only` or equivalent output for iterative flows.

Delta output should emphasize:
- what changed
- what matters now
- what is blocked
- what to do next
- where the full artifact lives

### R4. Inner loops should avoid prose duplication

Recursive or machine loops should prefer structured compact outputs over long prose paragraphs.

### R5. Artifact-backed reporting should be standard

Long detail should go into runtime artifacts or exported documents. Chat or terminal summaries should stay thinner.

## Structured machine contract

Inner-loop outputs should look more like typed records than essays.

Suggested schema:

```json
{
  "profile": "brief",
  "verdict": "pass|warn|fail|changes-requested",
  "summary": "one-line status",
  "findings": [
    {
      "id": "F-001",
      "severity": "low|medium|high|critical",
      "title": "string",
      "why": "short reason",
      "evidence": ["path or artifact id"],
      "recommendation": "small action"
    }
  ],
  "metrics": {
    "filesTouched": 0,
    "duplicateGroups": 0,
    "estimatedSavedTokens": 0
  },
  "nextAction": "string",
  "artifactRefs": ["string"]
}
```

This keeps outputs compact and composable.

## Human narrative contract

The human-facing layer should render from structured results and add:
- prioritization
- reasoning
- trade-offs
- confidence explanation
- selective examples
- concise next steps

But it should not repeat the full background every time.

## Token budget controls

Harness Forge should add output budget controls such as:
- `maxOutputTokens`
- `maxFindings`
- `maxExamples`
- `includeRationale`
- `includeAlternatives`
- `deltaOnly`
- `artifactFirst`

These can be mapped by profile.

Example:

```json
{
  "profiles": {
    "brief": {
      "maxOutputTokens": 300,
      "maxFindings": 3,
      "includeRationale": "minimal",
      "includeAlternatives": false,
      "deltaOnly": true
    },
    "standard": {
      "maxOutputTokens": 900,
      "maxFindings": 7,
      "includeRationale": "moderate",
      "includeAlternatives": true,
      "deltaOnly": false
    },
    "deep": {
      "maxOutputTokens": 3000,
      "maxFindings": 15,
      "includeRationale": "full",
      "includeAlternatives": true,
      "deltaOnly": false
    }
  }
}
```

## Review-specific policy

A good review does not need to narrate everything.

### Recommended review structure
1. verdict
2. top findings only
3. why they matter
4. next change or command
5. optional artifact reference

### Example: `brief` review

```md
Verdict: changes requested

High priority
- duplicate retrieval risk between wrapper and canonical skill body
- target bridge exceeds hot-path size budget

Next step
- convert wrapper to pointer format
- move long explanation into canonical runtime doc
```

### Example: `standard` review

```md
Verdict: changes requested

Main issue
The current target bridge duplicates too much canonical guidance, which increases first-hop token load and increases the chance of repeated retrieval.

Why it matters
That wastes tokens in both orientation and review loops, and makes it harder for an agent to know which copy is authoritative.

Suggested fix
Trim the bridge to a discovery wrapper and move the long body into the canonical `.hforge` surface.
```

## Recursive workflow policy

Recursive workflows are especially dangerous for output spend, because they create nested narrative loops.

### Recommended rule
- worker agents default to `brief`
- orchestrator can request `standard` when synthesis is needed
- final user-facing answer defaults to `standard`
- `deep` is opt-in or policy-triggered

### Example
A recursive code review with 12 workers should not produce 12 essays. It should produce:
- 12 brief records
- one orchestrator synthesis
- one optional deep artifact

## Artifact-first reporting

Long detail should be stored in artifacts, not repeated into every response.

Examples:
- `.hforge/runtime/reviews/<id>.json`
- `.hforge/runtime/reviews/<id>.md`
- `.hforge/runtime/recursive/sessions/<id>/runs/<runId>.json`
- exported markdown or zip bundles

Then the terminal or chat output can say:
- verdict
- top issues
- artifact path

This is much cheaper than streaming the full detail every time.

## Requirements for command surfaces

Every reporting command should support:
- `--brief`
- `--standard`
- `--deep`
- `--delta-only`
- `--summary-only`
- `--max-findings <n>`

Optional but valuable:
- `--artifact-first`
- `--max-output-tokens <n>`

## Requirements for runtime policy files

The runtime should be able to store default policy in a machine-readable form.

Suggested file:
- `.hforge/runtime/output-policy.json`

Suggested responsibilities:
- global defaults
- actor-based defaults
- workflow-based overrides
- hard caps
- audit thresholds
- command-to-profile mappings

## Reasoning behind the policy

### 1. The most expensive output is repeated explanation
Many systems do not spend most of their output tokens on genuinely new reasoning. They spend them on reintroducing context or narrating the same structure again.

### 2. Humans and machines need different verbosity
A recursive worker does not need to sound polished. It needs to be correct, compact, and composable.

### 3. Good structure improves quality
Shorter output with stronger prioritization often feels smarter, not weaker.

### 4. Artifacts preserve depth without polluting the loop
You can keep rich depth in files while keeping the conversational surface lean.

## Anti-patterns

### Anti-pattern A: every step writes a mini-report
This is the classic token sink.

### Anti-pattern B: one default verbosity for every actor
Different workflows have different needs.

### Anti-pattern C: brief mode that hides actionable evidence
Brevity is not an excuse for dropping evidence or next actions.

### Anti-pattern D: deep mode as the implicit default
Deep should be a choice, not a silent tax.

## Acceptance criteria

This policy is successful when:
1. worker outputs become materially smaller
2. operator-facing answers remain useful
3. repeated narrative drops
4. delta mode is adopted for iterative loops
5. detail moves into runtime artifacts instead of chat
6. output profiles are consistent across commands and target surfaces

## Final design statement

The cheapest good answer is not the shortest answer.  
It is the answer that contains only the information needed for the next correct move.
