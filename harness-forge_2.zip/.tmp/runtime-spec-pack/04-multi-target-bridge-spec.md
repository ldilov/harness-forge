# Multi-Target Bridge Specification

## Purpose

Define how Harness Forge should support `AGENTS.md`, `CLAUDE.md`, Codex-style proprietary surfaces, and future target-specific formats without fragmenting the canonical runtime or multiplying duplicated text.

## Problem statement

Multi-target support creates a predictable risk:

- every target wants its own visible integration surface
- every surface is tempted to become "the real instructions"
- duplicated instructions drift over time
- retrieval becomes noisy
- target support claims become overstated or inconsistent

Harness Forge already has the right directional pattern: thin visible bridge surfaces and a shared hidden runtime. This document turns that into a formal multi-target contract.

## Core thesis

Targets should have native bridges.  
The runtime should still have one canonical center.

That means:
- target-native surface where needed
- shared runtime beneath
- consistent authority model
- target-specific projections only when necessary
- bridge size discipline

## Scope

This spec covers:
- `AGENTS.md`
- `CLAUDE.md`
- Codex-style files such as `.codex/config.toml`
- target adapter manifests
- future proprietary bridge formats

This spec does not require every target to support every capability natively. It requires honest mapping and clear fallback behavior.

## Terminology

### Bridge surface
The file or folder a target naturally reads first.

Examples:
- `AGENTS.md`
- `CLAUDE.md`
- `.codex/config.toml`
- a future vendor-specific instruction file

### Shared runtime
The hidden canonical layer under `.hforge/` that contains the real skills, rules, knowledge, templates, and runtime state.

### Adapter
The target-specific mapping definition that explains:
- what paths get installed
- what target features are supported
- which bridges exist
- how shared runtime is exposed
- what is native versus translated

### Projection
A target-specific emitted artifact derived from shared runtime content.

## Design principles

### P1. Native where necessary, shared where possible
A target should get the file shape it expects, but the content should still point into shared canonical runtime.

### P2. Thin bridges
Bridge files should orient, map, and constrain. They should not become second canonical bodies.

### P3. Honest capability claims
If a target only supports translated or bridged behavior, the platform must say so.

### P4. Same concept, multiple shapes
The same runtime concept may appear as:
- markdown bridge
- JSON adapter entry
- TOML config hint
- generated launcher
- target-native template pointer

But it should still resolve to one canonical concept.

## Requirements

### R1. Every target must have an adapter contract

Each target should define:
- target ID
- display name
- install root strategy
- path mappings
- merge rules
- capability flags
- shared runtime bridge metadata
- authoritative surfaces
- visible bridge paths
- support mode notes

### R2. Bridge files must point inward

Target bridges must explicitly point to shared runtime roots and canonical authority paths.

They should answer:
- where canonical skills live
- where rules live
- where knowledge lives
- where templates live
- where runtime findings live
- which target-specific files are only bridges

### R3. Target-specific files must not overtake canonical bodies

A `CLAUDE.md` or Codex config should not silently become the real canonical skill library. It should remain a bridge or projection unless the architecture explicitly says otherwise.

### R4. Install-time projections should be traceable

If content is emitted into target-specific folders, those files should declare:
- origin concept
- origin path
- target ID
- canonicality status
- projection type

### R5. Merge behavior must be explicit

Targets differ. Some may want copy semantics, some append-once, some generated managed blocks.

The adapter contract must declare merge rules rather than relying on ad hoc installer behavior.

## Bridge model by target

## `AGENTS.md`

### Role
Cross-target, human-readable first bridge. Useful for both humans and some agents.

### Recommended content
- what Harness Forge is doing in this workspace
- thin explanation of `.hforge` as canonical runtime
- discovery-first load order
- trust/scope rules
- command catalog pointer
- runtime state pointer
- warning that target-specific visible files are bridges, not the canonical knowledgebase

### Must not become
- a full mirror of all skills
- a full rules encyclopedia
- a giant historical design document

## `CLAUDE.md`

### Role
Claude-native bridge surface.

### Recommended content
- concise target-specific bootstrapping notes
- pointer to `.hforge` authority
- pointer to `.agents/skills`
- pointer to `.claude/settings.json` or hooks if relevant
- clear statement about visible versus canonical layers

### Must not become
- a second full AGENTS body
- a copy of all runtime guidance
- a maintainer provenance archive

## Codex-style proprietary surface

Codex-style support often wants a vendor-native configuration surface such as `.codex/config.toml`.

### Role
Machine-oriented target bridge with small configuration and clear pointer into the shared runtime.

### Recommended content
- target configuration
- pointer to `AGENTS.md`
- pointer to `.agents/skills`
- pointer to `.hforge/runtime/*`
- enablement of target-appropriate templates or defaults

### Must not become
- a full prose instruction novel
- an unmanaged alternate runtime
- a target-specific replacement for `.hforge`

## Future proprietary formats

Harness Forge should be able to support future formats by introducing a new adapter without rewriting the canonical runtime architecture.

### Requirement
The adapter abstraction must be general enough for:
- markdown instruction files
- TOML or YAML config
- JSON config
- directory-based target bundles
- launcher or plugin projections

## Generic target adapter schema

```json
{
  "id": "target-id",
  "displayName": "Target Name",
  "installRootStrategy": "repo-root",
  "pathMappings": {},
  "mergeRules": {},
  "supportsHooks": false,
  "supportsCommands": true,
  "supportsAgents": true,
  "supportsContexts": true,
  "supportsPlugins": false,
  "sharedRuntimeBridge": {
    "instructionSurfaces": [],
    "runtimeSurfaces": [],
    "supportMode": "native|translated|bridged|partial",
    "authoritativeSurfaces": [],
    "visibleBridgePaths": [],
    "visibilityMode": "hidden-ai-layer"
  },
  "guidanceTemplate": "target-template-id"
}
```

## Path mapping strategy

Path mappings should distinguish between:
- visible bridge install paths
- target-native runtime directories
- shared runtime canonical paths
- template projections

### Example pattern
- canonical source: `targets/codex/runtime/.codex`
- installed bridge path: `.codex`
- canonical shared runtime: `.hforge/*`

## Merge rule strategy

Recommended merge modes:
- `copy`
- `append-once`
- `managed-block`
- `merge-json-object`
- `merge-toml-table`
- `preserve-user-sections`

This avoids target installers inventing behavior on the fly.

## Target capability honesty

Not all targets support:
- hooks
- plugins
- recursive execution
- native agent directories
- runtime-native commands
- context files
- validation workflows

The adapter must be explicit about:
- native support
- translated support
- bridged support
- unsupported support

### Why this matters
Capability overclaiming creates false trust and bad prompting. An agent or operator should be able to tell whether a feature is:
- truly native
- approximated
- only documented
- unavailable

## Bridge size policy

Each bridge type should have a budget.

Suggested policy:
- `AGENTS.md`: concise but sufficient
- `CLAUDE.md`: even thinner if it mostly points to shared runtime
- `.codex/config.toml`: minimal and machine-oriented
- target-specific template projections: only what the target needs

This ensures multi-target support does not multiply hot-path size.

## Example architecture

### Installed workspace
- `AGENTS.md`
- `CLAUDE.md` or `.codex/config.toml`
- `.agents/skills/*`
- `.hforge/library/*`
- `.hforge/runtime/*`
- target-native runtime folder if required

### Behavior
1. target reads native bridge
2. bridge points to shared runtime
3. target-specific projection activates target-native behaviors
4. canonical execution contracts remain in `.hforge`

## Example: `AGENTS.md` bridge

```md
# Workspace guidance

Treat `.hforge/` as the canonical AI/runtime layer.

Load order
1. `.hforge/agent-manifest.json`
2. `.hforge/runtime/index.json`
3. `.hforge/runtime/authority-map.json`
4. `.hforge/runtime/context-budget.json`

Discovery bridges
- `.agents/skills/`
- target-native files such as `CLAUDE.md` or `.codex/config.toml`

Do not treat visible bridges as separate canonical knowledge systems.
```

## Example: `CLAUDE.md` bridge

```md
# Claude workspace bridge

Use the shared `.hforge/` runtime as canonical.

Read first
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`

Discovery paths
- `.agents/skills/`
- `.claude/settings.json`

Visible target files are bridges into the shared runtime, not separate authoritative systems.
```

## Example: Codex-style TOML bridge

```toml
# Codex runtime bridge

[discovery]
agents = "AGENTS.md"
skills = ".agents/skills"
runtime_index = ".hforge/runtime/index.json"
authority_map = ".hforge/runtime/authority-map.json"
context_budget = ".hforge/runtime/context-budget.json"

[mode]
shared_runtime = true
visibility = "hidden-ai-layer"
```

## Examples of supported target behavior modes

### Native
The target can directly use the projected surface with minimal translation.

### Bridged
The target can discover and use the surface, but some behavior is mediated through the shared runtime rather than the target itself.

### Translated
The target cannot do the behavior natively, but Harness Forge can translate the capability into a form the target can still consume.

### Partial
Only some parts are supported. The adapter must say which.

## Requirements for future-proofing

To support "any Codex proprietary format" or future vendor-specific formats, the system should avoid hardcoding target logic into canonical documents.

Instead:
- define canonical concepts once
- define adapter mappings per target
- emit target projections from adapters
- preserve one shared runtime core

## Anti-patterns

### Anti-pattern A: every target gets a full cloned guidance body
This multiplies drift and hot-path size.

### Anti-pattern B: target file contains more truth than canonical runtime
That inverts the architecture.

### Anti-pattern C: target claims are inferred from docs instead of adapter metadata
Support posture should be explicit and machine-readable.

### Anti-pattern D: install output hides provenance
Projections should remain traceable back to the canonical concept.

## Acceptance criteria

This spec is successful when:
1. `AGENTS.md`, `CLAUDE.md`, and Codex-style surfaces all work as native bridges
2. canonical truth still lives in one shared runtime
3. target projections stay thin and traceable
4. capability claims stay honest
5. multi-target support does not inflate first-hop prompt cost
6. future target formats can be added via adapters instead of architectural rewrites

## Final design statement

A good target bridge feels native to the target.  
A good runtime still has one canonical center.
