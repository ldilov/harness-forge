# Retrieval, Deduplication, and Authority Model

## Purpose

Define how Harness Forge can keep broad runtime capability while preventing repeated retrievals, ambiguous truth, and runaway context inflation.

## Problem statement

As Harness Forge grows, the same concept can appear in several places:
- authored source
- discovery wrapper
- generated runtime projection
- packaged distribution copy
- target-specific bridge material
- maintainer documentation
- optional knowledgebase export

Without a disciplined authority model, retrieval systems tend to:
1. return multiple copies of the same idea
2. rank the wrong copy
3. spend tokens on repeated context
4. amplify stale or non-authoritative projections
5. make the agent less confident about what is true

The problem is not duplication in the filesystem alone. The real problem is duplication in the retrieval graph.

## Governing rule

A concept may have many paths.  
A retrieval decision should still produce one authoritative answer.

## Model overview

Harness Forge should use a content-addressed authority model with explicit concept metadata.

Each meaningful unit of guidance should have:

- `conceptId`
- `canonicalPath`
- `contentHash`
- `surfaceRole`
- `retrievalTier`
- `aliasOf` when not canonical
- optional `projectionOf` for generated or transformed forms

This allows the runtime to distinguish:
- true canonical bodies
- short discovery wrappers
- target projections
- generated machine-oriented versions
- cold provenance

## Definitions

### Canonical body
The one path that owns the concept.

Examples:
- canonical skill execution contract
- canonical rule pack
- canonical runtime schema
- canonical adapter spec
- canonical task template

### Alias
A thin pointer or small wrapper that references a canonical body without reproducing it.

Examples:
- `.agents/skills/<skill>/SKILL.md` wrapper
- `AGENTS.md` bridge section
- a summarized target-facing instruction block

### Projection
A generated or transformed representation of a canonical body.

Examples:
- packaged install-time projection
- runtime-generated index
- target-specific emitted config block
- condensed knowledgebase export fragment

### Cold provenance
Useful for maintainers, but not part of default retrieval.

Examples:
- import ledgers
- authoring notes
- temporary unpacked source
- tests and coverage artifacts
- old migration notes
- archived ports

## Requirements

### R1. One canonical body per concept

Every concept must have exactly one canonical body in the active runtime.

**Requirement:** No concept may have multiple canonical bodies in one installation profile.

If two rich files seem equally canonical, that is a design bug.

### R2. Wrappers must be thin

Wrappers are for discovery, not duplication.

**Requirement:** Target wrappers and discovery wrappers should contain:
- purpose
- when to use
- canonical path
- concept ID
- optional very short summary
- optional loading hint

They should not duplicate the full body except where the target absolutely requires it.

### R3. Retrieval must dedupe by concept, not by path

**Requirement:** The retrieval layer should collapse results that share:
- same `conceptId`
- same `contentHash`
- same `aliasOf`
- or high-confidence near-duplicate status

The user should not see four versions of the same skill just because they live in four directories.

### R4. Canonicality must influence ranking

Retrieval ranking should prefer:
1. canonical body
2. canonical generated index if explicitly asked for machine-readable output
3. thin discovery wrapper if the user needs navigation only
4. cold provenance only when specifically requested

### R5. Cold surfaces should not pollute the hot path

Tests, temp imports, archived notes, and provenance should not be indexed as default high-priority retrieval surfaces.

### R6. Generated copies must self-identify

Generated projections must declare:
- whether they are canonical
- what concept they alias or project
- their retrieval priority
- whether they should be hidden in `kb-lean`

## Required metadata

## File-level front matter or adjacent metadata

Each managed AI-facing content file should be trackable with metadata fields similar to:

```yaml
conceptId: skill.typescript-engineering
canonical: true
canonicalPath: .hforge/library/skills/typescript-engineering/SKILL.md
surfaceRole: canonical-body
retrievalTier: warm
indexPriority: high
contentHash: sha256:...
```

For wrappers:

```yaml
conceptId: skill.typescript-engineering
canonical: false
aliasOf: skill.typescript-engineering
surfaceRole: discovery-wrapper
retrievalTier: hot
indexPriority: medium
contentHash: sha256:...
```

For generated projections:

```yaml
conceptId: skill.typescript-engineering
canonical: false
projectionOf: skill.typescript-engineering
surfaceRole: generated-projection
retrievalTier: cold
indexPriority: low
contentHash: sha256:...
```

## Retrieval tier model

### Hot
Readable early and cheaply.
Typical content:
- bridge files
- runtime indexes
- command catalog
- authority map
- context budgets
- active recommendations

### Warm
Load on task demand.
Typical content:
- canonical skills
- canonical rules
- active language packs
- framework packs
- task-specific runtime findings

### Cold
Discoverable, but excluded by default.
Typical content:
- tests
- temp directories
- provenance
- authoring notes
- import ledgers
- coverage outputs
- archived reference material

## Exact duplicate suppression

Exact duplicate suppression is the minimum bar.

**Requirement:** Build-time tooling should detect when the same content body appears verbatim in multiple active retrieval locations.

Recommended actions:
- fail CI if duplication exceeds threshold
- auto-suggest wrapper reduction
- auto-emit duplicate inventory report
- allow explicit whitelists when duplication is required

## Near-duplicate suppression

Exact match is not enough. Near-duplicate prose is often the real token leak.

**Requirement:** Harness Forge should add a near-duplicate detector for AI-facing content.

Candidate approaches:
- normalized-text hashing
- MinHash or simhash over paragraph shingles
- sentence embedding clustering for candidate review
- structured diff similarity for manifests and templates

Use cases:
- long wrappers that paraphrase the canonical body too closely
- target projections that repeat most of a skill
- docs that copy command guidance with small wording changes
- seeded packs that repeat the same common rules block

## Canonicality-aware retrieval ranking

## Suggested ranking formula

```text
retrievalScore =
  taskRelevance
  + canonicalBonus
  + freshnessBonus
  + tierBonus
  - duplicatePenalty
  - projectionPenalty
  - coldSurfacePenalty
```

### Ranking guidance

- canonical body gets highest canonical bonus
- alias wrapper is only preferred for navigation-style queries
- generated projection is only preferred if machine output or target-specific form is requested
- cold provenance is strongly penalized unless explicitly asked for

## Concrete wrapper strategy

### Bad pattern

A wrapper that copies most of the real skill:

```md
# TypeScript Engineering

[500+ lines copied from canonical skill body]
```

This creates:
- duplicated retrieval
- drift risk
- larger target payload
- confusing ranking

### Better pattern

```md
# TypeScript Engineering

Purpose: TypeScript-heavy implementation, architecture, review, typing, refactoring.

Use when:
- the repo is TypeScript-heavy
- the task depends on typing, API contracts, tooling, or build correctness

Canonical contract:
- `.hforge/library/skills/typescript-engineering/SKILL.md`

Concept ID:
- `skill.typescript-engineering`

Load hint:
- read the canonical contract only when the task truly needs it
```

This is still discoverable, but much cheaper.

## Knowledgebase export strategy

A knowledgebase export should not mirror the whole package.

### `kb-lean` principles
- keep canonical bodies
- keep tiny discovery bridges
- remove generated duplicates
- remove cold provenance
- remove coverage, temp, and nested archives
- reduce wrapper size aggressively
- preserve concept metadata

### `kb-lean` should include
- bridge files
- authority map
- context budget
- command catalog
- canonical skills/rules/knowledge/templates
- target adapter specs
- concise docs needed to understand runtime behavior

### `kb-lean` should exclude
- temp folders
- tests and coverage
- build outputs if canonical authored sources exist
- import ledgers unless explicitly requested
- archived packages
- duplicate target projections when adapter mappings are enough

## CI and validation requirements

### Duplicate inventory report
Emit:
- duplicate groups
- canonical representative
- duplicate paths
- total repeated token estimate
- severity

### Wrapper-size validation
Fail or warn when wrappers exceed configured budgets.

Suggested thresholds:
- target bridge wrapper: very small
- discovery skill wrapper: small
- generated projection: depends on target need
- canonical body: not limited by wrapper threshold, but still measurable

### Canonical coverage check
Every active concept should have:
- concept ID
- one canonical path
- zero or more aliases
- optional projections
- defined tier
- ranking metadata

### Cold-surface leakage check
Ensure excluded or cold directories are not accidentally promoted into hot retrieval.

## Example: concept graph

```json
{
  "conceptId": "skill.token-budget-optimizer",
  "canonicalPath": ".hforge/library/skills/token-budget-optimizer/SKILL.md",
  "aliases": [
    ".agents/skills/token-budget-optimizer/SKILL.md"
  ],
  "projections": [
    "dist/cli/.hforge/library/skills/token-budget-optimizer/SKILL.md"
  ],
  "tier": "warm",
  "preferredFor": ["execution", "deep-guidance"],
  "notPreferredFor": ["first-hop-orientation"]
}
```

## Example: retrieval behavior

### Query
"How should I reduce token waste during recursive reviews?"

### Desired outcome
1. return canonical token-budget skill or runtime policy
2. maybe return context-budget runtime file
3. suppress discovery wrapper duplicates
4. suppress generated packaged copy
5. suppress authoring provenance

### Why
The user needs the concept, not the filesystem history.

## Reasoning behind the model

This model is valuable for three reasons.

### 1. It preserves depth
Nothing important needs to be deleted. Rich capability can stay.

### 2. It reduces confusion
The agent can learn one concept once, not three slightly different copies.

### 3. It attacks the real token leak
The largest waste is not just large files. It is repeated retrieval of near-identical content.

## Anti-patterns

### Anti-pattern A: package path determines truth
Filesystem location alone should not define authority.

### Anti-pattern B: every target projection is equally retrievable
That inflates results and encourages target drift.

### Anti-pattern C: knowledgebase export mirrors install surface
A KB export should be optimized for retrieval, not for reproducing the package tree exactly.

### Anti-pattern D: duplicate suppression based only on exact hashes
Near-duplicate prose often causes almost as much waste as exact copies.

## Acceptance criteria

This model is successful when:
1. repeated retrieval results drop materially
2. canonical bodies are surfaced first
3. wrappers stay small
4. `kb-lean` exports are measurably smaller
5. generated projections no longer dominate search results
6. the platform still preserves deep runtime capabilities

## Final design statement

The filesystem can contain many representations.  
The retrieval system should still present one authoritative concept.
