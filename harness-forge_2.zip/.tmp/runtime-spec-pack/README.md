# Harness Forge Runtime & Token-Efficiency Design Pack

This pack turns the brainstorming into a concrete written specification set for Harness Forge.

## What is in this pack

- `01-runtime-native-agentic-architecture.md`  
  Command-optional, runtime-native architecture for autonomous agents and operators.

- `02-retrieval-dedup-and-authority-model.md`  
  A dedup-first retrieval model that keeps capability depth without noisy repeated retrieval.

- `03-output-token-policy-and-response-profiles.md`  
  A concrete model for reducing output-token spend while keeping useful results.

- `04-multi-target-bridge-spec.md`  
  A compatibility architecture for `AGENTS.md`, `CLAUDE.md`, Codex-style surfaces, and future proprietary formats.

- `05-rollout-plan-validation-and-ci-gates.md`  
  Implementation plan, acceptance criteria, validation rules, and rollout strategy.

- `06-example-artifacts-and-schemas.md`  
  Example JSON, TOML, Markdown, and manifest files that show how the design works in practice.

- `Harness-Forge-Runtime-Spec-Master.md`  
  A single combined master document.

## Design thesis

Harness Forge should not become smaller by deleting capability.  
It should become sharper by shrinking the hot path and making deeper capability lazy, discoverable, and canonical.

The governing rule is:

> Everything should be discoverable.  
> Not everything should be preloaded.  
> Only one thing should be canonical.

## Reading order

1. Runtime architecture
2. Retrieval and deduplication
3. Output token policy
4. Target bridges
5. Rollout and CI
6. Example artifacts

## Intended audiences

- package maintainers
- runtime architects
- AI workflow designers
- operator experience owners
- target-adapter implementers
- knowledgebase/export maintainers
