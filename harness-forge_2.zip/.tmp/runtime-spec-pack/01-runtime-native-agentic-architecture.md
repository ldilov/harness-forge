# Harness Forge Runtime-Native Agentic Architecture

## Purpose

Define a runtime architecture where Harness Forge behaves like a native agentic operating layer rather than a pile of static text assets or a command-only tool. The operator may execute commands, but agents must be able to orient themselves, discover authoritative guidance, and escalate into deeper capability without being forced through a CLI entrypoint.

## Problem statement

Harness Forge is growing into a serious runtime platform. That is good. The risk is not capability growth itself. The risk is that the agent-facing surface becomes wide, repetitive, and ambiguous enough that the following failure modes appear:

1. The agent loads too much text too early.
2. The agent cannot tell what is canonical.
3. The agent retrieves the same idea from several mirrored surfaces.
4. The operator sees too many commands and too much prose before reaching the next useful action.
5. Runtime power is present, but hidden behind execution patterns that autonomous agents do not naturally follow.

The correct response is not capability reduction. The correct response is to make the runtime layered.

## Architecture principle

Harness Forge should distinguish three classes of surfaces:

1. **Discovery surfaces**  
   Tiny files that tell an agent where truth lives, how to navigate, and how to budget context.

2. **Authority surfaces**  
   Canonical files that contain the real execution contract, real policy, real rules, or real runtime state.

3. **Execution surfaces**  
   Commands, generated launchers, and target-native entrypoints used when the agent or operator wants runtime help, automation, or validation.

These classes must not be collapsed into one another.

## Non-goals

This architecture is not trying to:
- eliminate CLI usage
- eliminate rich skills or deep knowledge
- replace target-native integrations with one generic file
- make every target behave identically
- remove generated content from the package entirely

## Core requirement set

### R1. Command-optional orientation

An agent must be able to orient itself without executing a command.

**Requirement:** A fresh agent session in an installed workspace must be able to answer these questions from small runtime files:

- What am I looking at?
- Where is the authoritative AI/runtime layer?
- Which files are discovery wrappers versus canonical bodies?
- Which commands exist if I need them?
- Which runtime artifacts are safe to trust first?
- Which deeper surfaces are available for my task?

**Minimum orientation pack**
- `AGENTS.md`
- `.hforge/agent-manifest.json`
- `.hforge/runtime/index.json`
- `.hforge/runtime/authority-map.json`
- `.hforge/runtime/context-budget.json`

This pack must stay small, stable, and intentionally written.

### R2. Canonical runtime under hidden shared layer

The runtime should preserve the current idea that thin target-facing bridges point into a hidden, shared, canonical layer.

**Requirement:** For installed workspaces, canonical AI content should live under `.hforge/` and target-specific bridges should remain intentionally thin.

This avoids target divergence and keeps one shared truth for:
- skills
- rules
- knowledge
- templates
- runtime findings
- generated catalogs
- observability
- recursive runtime state

### R3. First-hop load budget

The first load should be extremely cheap.

**Requirement:** The total first-hop orientation payload should be constrained by explicit token budgets.

Recommended target:
- `AGENTS.md`: concise bridge file
- manifest + runtime indexes: mostly machine-readable
- combined first-hop load target: under 6k to 12k tokens in realistic deployments

The exact number can vary by profile, but the principle must not.

### R4. Layered hydration

Agents should not preload all depth. They should hydrate depth only when needed.

**Requirement:** Every runtime surface must belong to a load tier:
- **hot**: read first
- **warm**: load when task-relevant
- **cold**: discoverable, but excluded from default retrieval and hot-path loading

### R5. Capability discovery without guesswork

The runtime must answer "what can I do here?" without relying on heuristic scanning alone.

**Requirement:** The runtime must expose machine-readable capability and surface catalogs:
- command catalog
- authority map
- surface tier map
- target capability map
- active recommendations map
- runtime health/findings map

### R6. Human and machine modes should coexist

The operator and the autonomous agent are both first-class users.

**Requirement:** For the same installation:
- operators can inspect and run commands directly
- agents can discover fundamentals passively
- both can converge on the same canonical runtime truth

## Layer model

## Layer A: Bootstrap surfaces

These are the tiny first files that establish context and point to deeper truth.

### Example responsibilities

`AGENTS.md`
- human-readable bridge
- load order hints
- high-level trust/scope rules
- warning not to treat generated/runtime surfaces as product code
- minimal "how to orient" guidance

`.hforge/agent-manifest.json`
- machine-readable contract
- target compatibility
- canonical roots
- generated surfaces
- treat-as-product flags
- discovery bridge references

`.hforge/runtime/index.json`
- index of runtime artifact categories
- paths to runtime findings, recommendations, and current state

`.hforge/runtime/authority-map.json`
- canonical source for each concern
- alias relationships
- retrieval ranking hints

`.hforge/runtime/context-budget.json`
- load order
- token budgets
- suggested exclusions
- brief versus standard versus deep defaults

### Design constraint

These files should reference depth, not reproduce depth.

That means:
- do not duplicate full skill bodies
- do not inline huge rule packs
- do not mirror long templates
- do not include verbose provenance

## Layer B: Resolution surfaces

These files tell the agent how to resolve a task into the right authority surfaces.

Examples:
- `.hforge/generated/agent-command-catalog.json`
- `.hforge/runtime/repo/recommendations.json`
- `.hforge/runtime/repo/repo-map.json`
- `.hforge/runtime/repo/instruction-plan.json`
- `.hforge/runtime/recursive/language-capabilities.json`
- `.hforge/runtime/findings/risk-signals.json`

The agent should be able to answer:
- Which language pack matters?
- Which framework pack matters?
- Which commands are valid?
- Which target-specific capability claims are real?
- Which runtime issues already exist?
- Which paths are safe to ignore?

## Layer C: Deep capability surfaces

These include:
- canonical skills
- canonical rules
- canonical language or framework knowledge
- templates
- runtime traces
- task packs
- recursive run data
- optional provenance and authoring docs

These surfaces are rich and useful, but must not be part of the first-hop load unless the task requires them.

## Runtime contract

The runtime contract should look like this:

1. The agent reads a bridge.
2. The bridge points to the canonical manifest and runtime index.
3. The runtime index points to authority and budget files.
4. The authority map tells the agent what is canonical for the task.
5. The context budget tells the agent what to load next and what to avoid.
6. Optional commands or launchers accelerate work, but are not mandatory.

## Why this is better than command-first design

A command-first design assumes agents naturally ask, "What commands are available?" That is often false. Many agents first read local text, infer structure, and then decide whether to execute anything.

A runtime-native design works with that instinct instead of fighting it.

Advantages:
- less initial friction
- better autonomous discovery
- easier compatibility with multiple target ecosystems
- clearer canonicality model
- lower prompt bloat
- fewer duplicated explanations in chat output

## Required runtime files

### `.hforge/runtime/authority-map.json`

Purpose:
- map conceptual concerns to canonical paths
- mark aliases and generated projections
- drive retrieval deduplication
- help both agents and commands converge on the same truth

Minimum fields:
- `schemaVersion`
- `generatedAt`
- `concepts[]`
  - `conceptId`
  - `title`
  - `canonicalPath`
  - `aliases[]`
  - `surfaceType`
  - `tier`
  - `indexPriority`
  - `reasonToLoad`
  - `reasonToAvoid`

### `.hforge/runtime/context-budget.json`

Purpose:
- encode token budgets and default loading policies

Minimum fields:
- `schemaVersion`
- `profiles`
  - `brief`
  - `standard`
  - `deep`
- `hotSurfaces`
- `warmSurfaces`
- `coldSurfaces`
- `dropOrder`
- `taskProfiles`
- `maxFirstHopTokens`

### `.hforge/runtime/surface-tiers.json`

Optional but recommended.

Purpose:
- explicit hot/warm/cold classification across the installed surface

## Requirements for installation profiles

Harness Forge should support installation or export profiles that control what becomes part of the active runtime.

### Proposed profiles

#### `runtime-minimal`
Smallest viable self-discovery runtime.
Use when:
- minimal prompt cost matters
- a repo already has strong local code context
- the user wants native runtime orientation with lean surface

#### `runtime-standard`
Default recommended install.
Use when:
- broad capability is desired
- retrieval should still be disciplined
- common operators and agents need a balanced experience

#### `maintainer-full`
Full authoring and provenance surface.
Use when:
- editing the package itself
- auditing imports
- reviewing embedded ports and provenance
- working on release internals

#### `kb-lean`
A retrieval-optimized export with canonical bodies and discovery wrappers only.
Use when:
- uploading to a knowledgebase
- indexing in prompt-heavy environments
- sharing runtime guidance with minimal duplication

## Requirements for bridge files

Bridge files must:
- stay short
- tell the truth
- point to canonical runtime paths
- avoid capability overclaiming
- avoid duplicated full-content mirrors
- explain the difference between source-of-truth and generated/runtime surfaces

Bridge files must not:
- contain complete copies of large skills
- act as a second canonical documentation layer
- include hidden historical material
- include temporary import provenance by default

## Example flow: no-command agent orientation

### Scenario
A fresh agent is dropped into an installed workspace.

### Expected behavior
1. Read `AGENTS.md`
2. Learn `.hforge` is canonical
3. Read `.hforge/agent-manifest.json`
4. Read `.hforge/runtime/index.json`
5. Read `.hforge/runtime/authority-map.json`
6. Read `.hforge/runtime/context-budget.json`
7. Decide whether to inspect recommendations, command catalog, or task/runtime findings
8. Optionally execute a command

### Why this works
The agent stays autonomous, but avoids reading a huge surface. The runtime gives just enough structure to make the next read intelligent.

## Example flow: operator-first execution

### Scenario
An operator wants fast help and prefers commands.

### Expected behavior
1. Read bridge or run `hforge commands --json`
2. Inspect `hforge status --root . --json`
3. Use review, update, task, or target inspect commands
4. Refer back to the same `.hforge/runtime/*` truth used by agents

### Why this matters
The runtime architecture should not split operator truth from agent truth. Commands should accelerate access to the same canonical state.

## Anti-patterns

### Anti-pattern A: giant bridge files
A huge `AGENTS.md` that embeds skills, rules, templates, and provenance feels convenient, but destroys first-hop cost and encourages stale duplication.

### Anti-pattern B: every target as its own knowledge system
If `AGENTS.md`, `CLAUDE.md`, `.codex`, and other target surfaces all become separate canonical bodies, the platform eventually becomes inconsistent and expensive.

### Anti-pattern C: generated files pretending to be authored canonical content
Generated runtime projections are useful, but they must be clearly labeled as projections or aliases.

### Anti-pattern D: command-only discoverability
A runtime that only explains itself after running commands is not truly native for autonomous agents.

## Acceptance criteria

This architecture is successful when:

1. A fresh agent can orient itself without commands.
2. The first-hop token cost stays low and measurable.
3. Canonicality is obvious and machine-readable.
4. Deep capability remains available without preload.
5. Operators and agents converge on the same runtime truth.
6. Multi-target bridge files remain thin and honest.
7. Retrieval uses concept-level deduplication rather than file-path fanout.

## Final design statement

Harness Forge should behave like a layered runtime:
- small to enter
- rich to explore
- clear to trust
- optional to execute
- canonical at the center
