#!/usr/bin/env sh
set -eu

TARGET_ROOT="${1:-.}"
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OVERLAY_DIR="$SCRIPT_DIR/overlay"

if [ ! -d "$OVERLAY_DIR" ]; then
  echo "overlay directory not found: $OVERLAY_DIR" >&2
  exit 1
fi

mkdir -p "$TARGET_ROOT"
(
  cd "$OVERLAY_DIR"
  tar cf - .
) | (
  cd "$TARGET_ROOT"
  tar xf -
)

echo "[OK] overlay copied into $TARGET_ROOT"
