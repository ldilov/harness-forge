# Harness Forge slash-command pack

This pack gives you a Speckit-style command surface for Harness Forge using the same `.agents/skills/` pattern your package already ships.

Included:
- `/hforge-init`
- `/hforge-analyze`
- `/hforge-review`
- `/hforge-refresh`
- `/hforge-decide`
- heuristic patches that reduce false-positive language and framework routing

## Fast embed

### Option A - copy with the helper script

From the extracted pack directory:

```bash
./apply-overlay.sh /path/to/harness-forge
```

On PowerShell:

```powershell
./apply-overlay.ps1 -TargetRoot C:\path	o\harness-forge
```

### Option B - copy manually

Copy everything under `overlay/` into the Harness Forge repo root, preserving paths.

## What gets added or replaced

### New slash-command surfaces

- `.agents/skills/hforge-init/SKILL.md`
- `.agents/skills/hforge-analyze/SKILL.md`
- `.agents/skills/hforge-review/SKILL.md`
- `.agents/skills/hforge-refresh/SKILL.md`
- `.agents/skills/hforge-decide/SKILL.md`
- `skills/hforge-init/**`
- `skills/hforge-analyze/**`
- `skills/hforge-review/**`
- `skills/hforge-refresh/**`
- `skills/hforge-decide/**`

### Heuristic replacements

- `src/application/recommendations/recommend-bundles.ts`
- `scripts/intelligence/shared.mjs`

## Why the heuristic patch is included

Your current heuristics over-promote JavaScript repos into the TypeScript bundle and allow fixture or temp content to pollute recommendations.

This patch does four things:
- stops `.js` and `.jsx` from auto-triggering `lang:typescript`
- keeps JavaScript visible in repo facts without requiring a non-existent `lang:javascript` bundle
- down-weights low-signal paths such as `.tmp`, `tmp`, `temp`, `fixtures`, and imported snapshots
- avoids treating bare `.h` files as enough evidence for C++ on their own

## Minimal embed steps inside Harness Forge

After copying files into the repo:

1. Check the new skill paths exist under both `.agents/skills/` and `skills/`
2. Run:

```bash
npm run build
npm test
npm run validate:doc-command-alignment
npm run validate:package-surface
npm run validate:release
```

## Validation note

The new skill files work immediately in your current package layout because `baseline:agents` already includes the full `.agents/skills` and `skills` directories.

If you want package-surface validation to enforce these new skills, add these paths to `manifests/catalog/package-surface.json` under `requiredPaths`:

```text
.agents/skills/hforge-init/SKILL.md
.agents/skills/hforge-analyze/SKILL.md
.agents/skills/hforge-review/SKILL.md
.agents/skills/hforge-refresh/SKILL.md
.agents/skills/hforge-decide/SKILL.md
skills/hforge-init/SKILL.md
skills/hforge-analyze/SKILL.md
skills/hforge-review/SKILL.md
skills/hforge-refresh/SKILL.md
skills/hforge-decide/SKILL.md
```

## Optional follow-up cleanups

These are not required for the commands to work, but they keep the repo tidy:
- mention the new slash commands in `docs/commands.md`
- add them to any maintainer-facing docs that list notable skills
- add compatibility-matrix entries only if you want them called out explicitly in generated support docs

## How these commands map to current HForge behavior

- `/hforge-init` -> bootstrap and first-pass runtime setup
- `/hforge-analyze` -> repo understanding, runtime findings, and decision-candidate capture
- `/hforge-review` -> health, drift, decision coverage, and stale-task review
- `/hforge-refresh` -> regenerate runtime summaries after install or content changes
- `/hforge-decide` -> create or update durable ASR or ADR records in `.hforge/runtime/decisions/`

## Important scope note

These files follow the same project-local command wrapper style you already use for Speckit under `.agents/skills/`. They are designed to slot into your existing Harness Forge pattern rather than introduce a second command system.
