param(
  [string]$TargetRoot = "."
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$OverlayDir = Join-Path $ScriptDir "overlay"

if (-not (Test-Path $OverlayDir)) {
  throw "overlay directory not found: $OverlayDir"
}

if (-not (Test-Path $TargetRoot)) {
  New-Item -ItemType Directory -Path $TargetRoot | Out-Null
}

Copy-Item -Path (Join-Path $OverlayDir '*') -Destination $TargetRoot -Recurse -Force
Copy-Item -Path (Join-Path $OverlayDir '.*') -Destination $TargetRoot -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[OK] overlay copied into $TargetRoot"
