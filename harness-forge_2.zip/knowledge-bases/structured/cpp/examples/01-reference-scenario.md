# Reference scenario

Use this example as a template for implementing and validating a small C++ change with the promoted rules and workflow template.
